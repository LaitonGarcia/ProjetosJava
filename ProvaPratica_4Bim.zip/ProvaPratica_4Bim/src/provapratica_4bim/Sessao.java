/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package provapratica_4bim;

/**
 *
 * @author GARCIA
 */
public class Sessao {
    private double valorDaHora = 3.5;// garantindo um valor mínimo a cobrar
    private double totalAPagar;
    private Data dataSessao = new Data();
    private Horas inicioSessao = new Horas();
    private Horas encerraSessao = new Horas();
    private Computador maquina = new Computador();
    private Cliente cliente = new Cliente();

    public double getValorDaHora() {
        return valorDaHora;
    }

    public void setValorDaHora(double valorDaHora) {
        this.valorDaHora = valorDaHora;
    }

    public double getTotalAPagar() {
        return totalAPagar;
    }

    public void setTotalAPagar(double totalAPagar) {
        this.totalAPagar = totalAPagar;
    }

    public Data getDataSessao() {
        return dataSessao;
    }

    public void setDataSessao(Data dataSessao) {
        this.dataSessao = dataSessao;
    }

    public Horas getInicioSessao() {
        return inicioSessao;
    }

    public void setInicioSessao(Horas inicioSessao) {
        this.inicioSessao = inicioSessao;
    }

    public Horas getEncerraSessao() {
        return encerraSessao;
    }

    public void setEncerraSessao(Horas encerraSessao) {
        this.encerraSessao = encerraSessao;
    }

    public Computador getMaquina() {
        return maquina;
    }

    public void setMaquina(Computador maquina) {
        this.maquina = maquina;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    public void calcularTotalPagar(){
        totalAPagar = (encerraSessao.getHora()-inicioSessao.getHora())*valorDaHora;
    }
    public void mostrarSessao(){
        System.out.println("Valor da Hora: "+valorDaHora);
        System.out.println("Total a pagar: "+totalAPagar);
        System.out.println("Data: "+dataSessao.mostrarData());
        System.out.println("Inicio da Sessao: "+inicioSessao.mostrarHora());
        System.out.println("Fechamento da Sessao: "+encerraSessao.mostrarHora());
        System.out.println("Maquina: "+maquina.mostrarComputador());
        System.out.println("Cliente "+cliente.mostrarCliente());
    }
    public void resumoSessao(){
        System.out.println("Data: "+dataSessao.mostrarData());
        System.out.println("Total a pagar: "+totalAPagar);
        System.out.println("Máquina: "+maquina.getCodigoComputador());
    }
}// Fim classe Sessao
