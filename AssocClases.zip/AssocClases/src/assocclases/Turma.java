/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package assocclases;

/**
 *
 * @author GARCIA
 */
public class Turma {
    private Aluno aluno = new Aluno();
    private String nomeTurma;
    private String turno;

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public String getNomeTurma() {
        return nomeTurma;
    }

    public void setNomeTurma(String nomeTurma) {
        this.nomeTurma = nomeTurma;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }
    public String fichaTurma(){
        return "Turma: "+nomeTurma+"\nTurno "+turno+"\n"+aluno.getNome() ;
    }
    public double mediaTurma(){
       return aluno.media();
    }
    public void situacaoAluno(){
        if(aluno.media()>=7)
            System.out.println(" Aluno "+aluno.getNome()+" está Aprovado(a)");
        else
            System.out.println(" Aluno "+aluno.getNome() +" está Reprovado(a)");
    }
}
