// varios exemplos do livro Deitel 8 edição

package aprendendojava;

public class AprendendoJava {

   
    public static void main(String[] args) { 
        PerguntasMostrar perguntas = new PerguntasMostrar();
        Calculos calculo = new Calculos();
                
         String sair;
        do{                     
             perguntas.subMenu();
             do{
                 sair = perguntas.continuarSair();
             }while(!calculo.somenteCharNum(sair));// enquanto retorna falso fica no loop
             
                         
        }while(calculo.ehNumero(sair));
 /*       
       boolean teste = verificarSeTamanhoInvalido("11111111113");
        System.out.println("este é o retorno: " + teste);
        
    }  
    private static boolean verificarSeTamanhoInvalido(String CPF){  
      //if ( cpf.length() != 11 )
       // return true;   
          return ( CPF.equals("00000000000") || CPF.equals("11111111111")||
                CPF.equals("22222222222") || CPF.equals("33333333333") ||
                CPF.equals("44444444444") || CPF.equals("55555555555") ||
                CPF.equals("66666666666") || CPF.equals("77777777777") ||
                CPF.equals("88888888888") || CPF.equals("99999999999") ||CPF.length() != 11 );
  
     }
   */ 
    }//fim do main
} // fim da classe
/*  Tudo isso estava no main


// Scanner leitura = new Scanner(System.in);
        Calculos calculo = new Calculos();
        PerguntasMostrar perguntas = new PerguntasMostrar();
        
        //System.out.println("Entre com o primeiro numero. ");
        int numero1 = perguntas.perguntaNum1();
        //System.out.println("Entre com o segundo numero. ");
        int numero2 = perguntas.perguntaNum2();

       // leitura.nextLine();       // esvaziando o buffer do teclado em Java
        
        //System.out.println("Qual o nome? ");
        String nome = perguntas.perguntaNome();
        //System.out.println();
        int resultado = numero1 + numero2;
        //System.out.printf("O resultado da soma é %d\n", calculo.soma(numero1,numero2));
        //System.out.println("Outra forma de mostrar o resultado " + (numero1 + numero2));
        //System.out.println("Mais outra forma resultado " + resultado);
        System.out.println("Meu nome é " + nome);
        perguntas.comparacao(numero1, numero2);
        perguntas.mostrarQuadrado(numero1);
        perguntas.mostrarCubo(numero2);
        //calculo.quadrado(numero1);
        //calculo.cubo(numero2);
    }
    */