

package datahoratestes;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class DataHoraTestes {

    
    public static void main(String[] args) {
        Date data = new Date();
        System.out.println(data);
        String sineta = ("11:34:30");
        String dataFormatada = null;
        while(!sineta.equals(dataFormatada)){
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        Date hora = Calendar.getInstance().getTime(); // Ou qualquer outra forma que tem
        dataFormatada = sdf.format(hora);
        System.out.println(dataFormatada);
        }
    }// fim do main
    
}// fim da classe
