/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package primeiroSemestre;

import java.util.Scanner;

/**
 *
 * @author GARCIA
 */
public class Aula_3_scanner_switch {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
         /*   
       // Limpando o Buffet do teclado 
        
        int numero;
        String nome;
        
        System.out.println("Digite seu nome: ");
        nome = input.nextLine();
        
        System.out.println("Digite um número: ");
        numero = input.nextInt();
        
       // input.nextLine();
        
         
        System.out.println(nome + " digitou o número " + numero);
   */    
   /*     
        int num_1, num_2, num_3, num_4, num_5;

        System.out.print("Digite o valor de a numero:");
        num_1 = input.nextInt();

        System.out.print("Digite o valor de b numero:");
        num_2 = input.nextInt();

        System.out.print("Digite o valor de c numero:");
        num_3 = input.nextInt();

        System.out.print("Digite o valor de d numero:");
        num_4 = input.nextInt();

        System.out.print("Digite o valor de e numero:");
        num_5 = input.nextInt();

        if (num_1>num_2 & num_2>num_3 & num_3>num_4 & num_4>num_5)
            System.out.printf("Resultado\nMaior numero e o a = %d\nMenor numero e o e =%d\n", num_1, num_5);

        if (num_2>num_1 & num_1>num_3 & num_3>num_4 & num_4>num_5)

            System.out.printf("Resultado\nMaior numero e o b = %d\nMenor numero e o e = %d\n", num_2, num_5);

        if (num_3>num_1 & num_1>num_2 & num_2>num_4 & num_4>num_5)
            System.out.printf("Resultado\nMaior numero e o c = %d\nMenor numero e o e = %d\n", num_3, num_5);

        if (num_4>num_1 & num_1>num_2 & num_2>num_3 & num_3>num_5)
            System.out.printf("Resultado\nMaior numero e o d = %d\nMenor numero e o e = %d\n", num_4, num_5);

        if (num_5>num_1 & num_1>num_2 & num_2>num_3 & num_3>num_4)
            System.out.printf("Resultado\nMaior numero e o e = %d\nMenor numero e o d = %d\n", num_5, num_4);

        if (num_1>num_2 & num_2>num_3 & num_3>num_5 & num_5>num_4)
            System.out.printf("Resultado\nMaior numero e o a = %d\nMenor numero e o d = %d\n", num_1, num_4);

        if (num_1>num_2 & num_2>num_4 & num_4>num_5 & num_5>num_3)
            System.out.printf("Resultado\nMaior numero e o a = %d\nMenor numero e o c = %d\n", num_1, num_3);

        if (num_1>num_3 & num_3>num_4 & num_4>num_5 & num_5>num_2)
            System.out.printf("Resultado\nMaior numero e o a = %d\nMenor numero e o b = %d\n", num_1, num_2);

        if (num_2>num_1 & num_1>num_3 & num_3>num_5 & num_5>num_4)
            System.out.printf("Resultado\nMaior numero e o b = %d\nMenor numero e o d = %d\n", num_2, num_4);

        if (num_2>num_1 & num_1>num_4 & num_4>num_5 & num_5>num_3)
            System.out.printf("Resultado\nMaior numero e o b = %d\nMenor numero e o c = %d\n", num_2, num_3);

        if (num_2>num_3 & num_3>num_4 & num_4>num_5 & num_5>num_1)
            System.out.printf("Resultado\nMaior numero e o b = %d\nMenor numero e o a = %d\n", num_2, num_1);

        if (num_3>num_1 & num_1>num_2 & num_2>num_5 & num_5>num_4)
            System.out.printf("Resultado\nMaior numero e o c = %d\nMenor numero e o d = %d\n", num_3, num_4);

        if (num_3>num_1 & num_1>num_4 & num_4>num_5 & num_5>num_2)
            System.out.printf("Resultado\nMaior numero e o c = %d\nMenor numero e o b = %d\n", num_3, num_2);

        if (num_3>num_2 & num_2>num_4 & num_4>num_5 & num_5>num_1)
            System.out.printf("Resultado\nMaior numero e o c = %d\nMenor numero e o a = %d\n", num_3, num_1);

        if (num_4>num_1 & num_1>num_2 & num_2>num_5 & num_5>num_3)
            System.out.printf("Resultado\nMaior numero e o d = %d\nMenor numero e o c = %d\n", num_4, num_3);

        if (num_4>num_1 & num_1>num_3 & num_3>num_5 & num_5>num_2)
            System.out.printf("Resultado\nMaior numero e o d = %d\nMenor numero e o b = %d\n", num_4, num_2);

        if (num_4>num_2 & num_2>num_3 & num_3>num_5 & num_5>num_1)
            System.out.printf("Resultado\nMaior numero e o d = %d\nMenor numero e o a = %d\n", num_4, num_1);

        if (num_5>num_1 & num_1>num_2 & num_2>num_4 & num_4>num_3)
            System.out.printf("Resultado\nMaior numero e o e = %d\nMenor numero e o c = %d\n", num_5, num_3);

        if (num_5>num_1 & num_1>num_3 & num_3>num_4 & num_4>num_2)
            System.out.printf("Resultado\nMaior numero e o e = %d\nMenor numero e o b = %d\n", num_5, num_2);

        if (num_5>num_2 & num_2>num_3 & num_3>num_4 & num_4>num_1)
            System.out.printf("Resultado\nMaior numero e o e = %d\nMenor numero e o a = %d\n", num_5, num_1);
   */
 /*    
     int num1;
     int num2;
     int operacao;
        
     System.out.print("Digite o valor de a numero:");
     num1 = input.nextInt();

     System.out.print("Digite o valor de b numero:");
     num2 = input.nextInt();   
     
     System.out.print("Escolha a operação:\nSoma 1\nSubtração 2\nMultiplicação 3\nDivisão 4\n :");
     operacao = input.nextInt();
       
        switch (operacao) {
        case 1:
            System.out.println("Soma: "+(num1 + num2));
            break;
        case 2:
            System.out.println("Subtração: "+(num1 - num2));
            break;
        case 3:
            System.out.println("Multiplicação: "+(num1 * num2));
            break;
        case 4:
            System.out.println("Divisão: "+(num1 / num2));
            break;
        default:
            System.out.println("Não existe essa opção!");
            break;
        }
 */
  /*
         char sinal;
         //String sinal;
         double numero1;
         double numero2;
         Scanner sc=new Scanner(System.in);
       
            
         System.out.println("Digite o primeiro numero");
         numero1 = sc.nextDouble();
         System.out.println("Digite o segundo numero");
         numero2 = sc.nextDouble();
         sc.nextLine();
         System.out.println("Digite o sinal '+' soma, '-' subtraçao, '*' multiplicaçao, '/' Divisão");
         sinal = sc.nextLine().charAt(0); // Pega somente o primeiro caractere da string
        //sinal = sc.nextLine();
        switch (sinal) {
        //switch (sinal.toLowerCase){ // toUpperCase
            case '+': // diferente da String o char usa aspas simples
            //case "soma":
                System.out.println(numero1+numero2);
                break;
            case '-':
            //case "subtracao":
                System.out.println(numero1-numero2);
                break;
            case '*':
            //case "multiplicacao":
                System.out.println(numero1*numero2);
                break;
            case '/':
            // case "divisao":
                System.out.println(numero1/numero2);
                break;
            default:
                System.out.println("Opção não existe!");
                break;
          } 
   */ 
 /*      //char sinal;
         String sinal;
         double numero1;
         double numero2;
         Scanner sc=new Scanner(System.in);
       
            
         System.out.println("Digite o primeiro numero");
         numero1 = sc.nextDouble();
         System.out.println("Digite o segundo numero");
         numero2 = sc.nextDouble();
         sc.nextLine();
         System.out.println("Digite o NOME");
         sinal = sc.nextLine();
         //
   */      
       /*  do{
         System.out.println("Digite o sinal '+' soma, '-' subtraçao, '*' multiplicaçao, '/' Divisão");
         //sinal = sc.nextLine().charAt(0); // Pega somente o primeiro caractere da string
         sinal = sc.nextLine();
         }while(!sinal.equals("s")&& !sinal.equals("d"));
         System.out.println("Saiu do while");
   */
  
        String diaSemana=null;
        int idade;
        System.out.println("Digite 0 (Zero) para Sair! ");
        do{
            do{
            System.out.print("\tBilheteria\n\n");

            System.out.print("Entre com o dia da semana:\n1 - Domingo\n");
            System.out.print("2 - Segunda\n3 - Terça\n4 - Quarta\n");
            System.out.print("5 - Quinta\n6 - Sexta\n7 - Sábado: \n");
            diaSemana = input.nextLine();
            }while(!diaSemana.matches("^[0-7]*$"));
        
        switch (diaSemana){
            case "3":
            case "4":
            case "5":
                System.out.println("Dia Promocional: MEIA ENTRADA!");
                break;
            case "1": case "2": case "6":
            case "7":
                System.out.println("Qual a idade do cliente? ");
                idade = input.nextInt();
                System.out.print("Cliente paga ");
                System.out.println(idade >= 12 && idade < 60 ? "INTEIRA!":"MEIA ENTRADA!");
                break;
           // default:
            //    System.out.print("\n\tDia da semana incorreto!");      
         }// fim do switch
        System.out.println("aqui ");
        }while( !diaSemana.equals("0") );
/*
    //int variavel;
    String variavel;
    //char variavel;
    double pi = 3.141516;

    System.out.print("\tDigite 1, 2 ou 3. \n");
    //variavel = input.nextInt();
    variavel = input.nextLine();
    // variavel = input.nextLine().charAt(0);
    switch (variavel.toLowerCase()){ //.toLowerCase() ou toUpperCase()
            
           // case "UM":
            case "um": // "" para String e '' para char
		System.out.println("Faz a Instução CASE 1.");
                break;
            case "dois":
                System.out.println("Faz a Instução CASE 2.");
		System.out.println("Mas poderia fazer várias outras instruções.");
		System.out.println("O valor de PI é: " + pi);
               break;
            case "tres":
                System.out.println("Aqui o Case vai findando!");
               break;
            default:
                System.out.print("E se nada deu certo mostra ao menos isso!\n");   
         }// fim do switch
  */ 
  /*
        // Exemplo de SWITCH sem BREAK
        double valorParcela;
        double totalDivida;
        int mesesAtraso;      // controlador do switch
        double taxaJuros = 1.05; // 5% acrescido em cada parcela
        
        System.out.println("Qual o vlor da parcela em atraso: ");
        valorParcela = input.nextDouble();
        System.out.println("Quantas parcelas em atraso: 1 - 5 ");
        mesesAtraso = input.nextInt();
        totalDivida = valorParcela;
        switch (mesesAtraso){           
            case 5: 
		totalDivida *= taxaJuros;
            case 4:
                totalDivida *= taxaJuros;             
            case 3:
                totalDivida *= taxaJuros;
            case 2:
                totalDivida *= taxaJuros;
            case 1:
                totalDivida *= taxaJuros;
                break;
            default:
                System.out.print("Excedeu quantidade de meses máxima!\n");   
         }// fim do switch
         if(mesesAtraso > 0 && mesesAtraso < 6 ){
              System.out.printf("Total da divida: %.2f\n", totalDivida);
              System.out.printf("Referente a parcela de: %.2f\n", valorParcela);
              System.out.printf("Com %d meses de atraso\n", mesesAtraso);
         }
   */ 
  /*     
        int num_1;
        int num_2;
        int num_3;
        int maiorNum;
        int menorNum;
        int meio = 0;
        int controleSwitch;

        System.out.print("Digite primeiro número inteiro:");
        num_1 = input.nextInt();
        System.out.print("Digite segundo número numero:");
        num_2 = input.nextInt();
        System.out.print("Digite terceiro número numero:");
        num_3 = input.nextInt();    
        
        maiorNum = num_1;
        if(num_2 > maiorNum)
            maiorNum = num_2;
        if(num_3 > maiorNum)
            maiorNum = num_3;
        
        menorNum = num_1;
        if(num_2 < menorNum)
            menorNum = num_2;
        if(num_3 < menorNum)
            menorNum = num_3;
        
        if(num_1 != maiorNum && num_1 != menorNum) 
            meio = num_1;
        else
            if(num_2 != maiorNum && num_2 != menorNum) 
                meio = num_2;
            else
                 meio = num_3;
        
        System.out.print("Escolha a operação:\n");
        System.out.print("1 - Maior Número\n2 - Menor Número\n");
        System.out.print("3 - Ordem Crescente\n4 - Ordem Decrescente: \n");
        controleSwitch = input.nextInt();
        
        switch (controleSwitch) {
        case 1:
            System.out.println("Maior número: "+maiorNum);
            break;
        case 2:
            System.out.println("Menor número: "+menorNum);
            break;
        case 3:
            System.out.println("Ordem Crescente "+menorNum+" "+meio+" "+maiorNum);
            break;
        case 4:
            System.out.println("Ordem Decrescente "+maiorNum+" "+meio+" "+menorNum);
            break;
        default:
            System.out.println("Não existe essa opção!");
            break;
        }
   */     
  /*
        int num_1;
        int num_2;
        int num_3;
        int maiorNum;
        int menorNum;
        int meio = 0;
        int controleSwitch;

        System.out.print("Digite primeiro número inteiro:");
        num_1 = input.nextInt();
        System.out.print("Digite segundo número numero:");
        num_2 = input.nextInt();
        System.out.print("Digite terceiro número numero:");
        num_3 = input.nextInt(); 
        
       maiorNum = Math.max(num_1, Math.max(num_2, num_3));
       menorNum = Math.min(num_1, Math.min(num_2, num_3));
        
       if(num_1 != maiorNum && num_1 != menorNum) 
            meio = num_1;
       else
           if(num_2 != maiorNum && num_2 != menorNum) 
                meio = num_2;
           else
               meio = num_3;
      
       System.out.print("Escolha a operação:\n");
       System.out.print("1 - Maior Número\n2 - Menor Número\n");
       System.out.print("3 - Ordem Crescente\n4 - Ordem Decrescente: \n");
       controleSwitch = input.nextInt();
        
        switch (controleSwitch) {
        case 1:
            System.out.println("Maior número: "+maiorNum);
            break;
        case 2:
            System.out.println("Menor número: "+menorNum);
            break;
        case 3:
            System.out.println("Ordem Crescente "+menorNum+" "+meio+" "+maiorNum);
            break;
        case 4:
            System.out.println("Ordem Decrescente "+maiorNum+" "+meio+" "+menorNum);
            break;
        default:
            System.out.println("Não existe essa opção!");
            break;
        } // fim do switch
  */    
 } // Fim do metodo main()    
} // }Fim da Classe Aula_segunda
