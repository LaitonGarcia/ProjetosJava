/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tela.web;

import dao.AlunoDAO;
import dao.conexao.ConnectionFactory;
import entidades.Aluno;
import entidades.util.Endereco;
import entidades.util.Rg;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sobral
 */
public class WebDao {

    public ArrayList<Aluno> pesquisarAlunosComPendencias() throws SQLException { // FALTA TESTAR
        System.out.println("Entrou no WebDAO");
        ResultSet res;
        String sql = "select * from auxiliar_web_local";
        PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
        ArrayList<Aluno> vetorAluno = new ArrayList<Aluno>();
        res = ps.executeQuery();
        try {
            while (res.next()) {
                Aluno aluno = new Aluno();
                Rg rg = new Rg();
                rg.setRg(res.getString("rg"));
                rg.setRgOrgaoEmissor(res.getString("rg_orgao_emissor"));
                rg.setRgOrgaoEmissorUf(res.getString("rg_orgao_emissor_uf"));
                aluno.setRg(rg);
                aluno.setCpf(res.getString("cpf"));
                aluno.setNome(res.getString("nome"));
                aluno.setDataNascimento(res.getDate("data_nascimento"));
                aluno.setEstadoCivil(res.getString("estado_civil"));
                aluno.setSexo(res.getString("sexo"));
                aluno.setFiliacaoMae(res.getString("filiacao_mae"));
                aluno.setFiliacaoPai(res.getString("filiacao_pai"));
                aluno.setEmail(res.getString("email"));
                aluno.setTelefone1(res.getString("telefone_1"));
                aluno.setTelefone2(res.getString("telefone_2"));
                Endereco endereco = new Endereco();
                endereco.setEndereco(res.getString("endereco"));
                endereco.setNumero(res.getString("numero"));
                endereco.setBairro(res.getString("bairro"));
                endereco.setMunicipio(res.getString("municipio"));
                endereco.setUf(res.getString("uf"));
                endereco.setCep(res.getString("cep"));
                aluno.setEndereco(endereco);
                vetorAluno.add(aluno);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        ConnectionFactory.getConexao().close();
        return vetorAluno;
    }

    public Aluno pesquisarAlunoComPendencia(String cpf) throws SQLException { // FALTA TESTAR
        ResultSet res;
        String sql = "select * from auxiliar_web_local where cpf='" + cpf + "';";
        System.out.println(sql);
        PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
        Aluno aluno = new Aluno();
        res = ps.executeQuery();
        try {
            while (res.next()) {
                Rg rg = new Rg();
                rg.setRg(res.getString("rg"));
                rg.setRgOrgaoEmissor(res.getString("rg_orgao_emissor"));
                rg.setRgOrgaoEmissorUf(res.getString("rg_orgao_emissor_uf"));
                aluno.setRg(rg);
                aluno.setCpf(res.getString("cpf"));
                aluno.setNome(res.getString("nome"));
                aluno.setDataNascimento(res.getDate("data_nascimento"));
                aluno.setEstadoCivil(res.getString("estado_civil"));
                aluno.setSexo(res.getString("sexo"));

                aluno.setFiliacaoMae(res.getString("filiacao_mae"));
                aluno.setFiliacaoPai(res.getString("filiacao_pai"));
                aluno.setEmail(res.getString("email"));
                aluno.setTelefone1(res.getString("telefone_1"));
                aluno.setTelefone2(res.getString("telefone_2"));
                Endereco endereco = new Endereco();
                endereco.setEndereco(res.getString("endereco"));
                endereco.setNumero(res.getString("numero"));
                endereco.setBairro(res.getString("bairro"));
                endereco.setMunicipio(res.getString("municipio"));
                endereco.setUf(res.getString("uf"));
                endereco.setCep(res.getString("cep"));
                aluno.setEndereco(endereco);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        ConnectionFactory.getConexao().close();
        return aluno;
    }

    public void deletarAluno(String cpf) throws SQLException { // FALTA TESTAR
        String sql = "delete  from auxiliar_web_local where  cpf= '" + cpf + "';";
        PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
        ps.executeUpdate();
        ConnectionFactory.getConexao().close();
    }

    public String[] alunoToLinha(Aluno aluno) {
        String[] novaLinha = new String[]{aluno.getCpf(), aluno.getNome()};
        return novaLinha;
    }

    public void atualizarAluno(Aluno aluno) {

        String sql = "update aluno set  filiacao_mae=?, filiacao_pai=?,"
                + "email=?, telefone_1=?, telefone_2=?, endereco=?, numero=?, bairro=?,municipio=?, uf=?, cep=? where cpf=?";
        try {
            PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);

            ps.setString(1, aluno.getFiliacaoMae());
            ps.setString(2, aluno.getFiliacaoPai());
            ps.setString(3, aluno.getEmail());
            ps.setString(4, aluno.getTelefone1());
            ps.setString(5, aluno.getTelefone2());
            ps.setString(6, aluno.getEndereco().getEndereco());
            ps.setString(7, aluno.getEndereco().getNumero());
            ps.setString(8, aluno.getEndereco().getBairro());
            ps.setString(9, aluno.getEndereco().getMunicipio());
            ps.setString(10, aluno.getEndereco().getUf());
            ps.setString(11, aluno.getEndereco().getCep());
            ps.setString(12, aluno.getCpf());
            ps.executeUpdate();
            ConnectionFactory.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
