
package testealunosimulado;
public class Aluno {
    private int matricula;
    private String nome;
    private double media;
    
    public Aluno(int matricula, String nome){
        this.matricula = matricula;
        this.nome = nome;
        this.media = 0;
    }
    
    public int getMatricula(){
        return this.matricula;
    }
    public void setMatricula(int matricula){
        this.matricula = matricula;
    }
    
    public String getNome(){
        return this.nome;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public double getMedia(){
        return this.media;
    }
    public void setMedia(double media){
        if(media < 0 || media > 10)
            System.out.println("\nMedia Invalida!");
        else
            this.media = media;
    }
    
    public String toStringAluno(){
        String aluno = "\nMatricula: "+this.matricula+
                "\nAluno: "+this.nome+
                "\nMedia: "+this.media;
        return aluno;
    }
    
    public void resultadoFinal(Aluno aluno){
        System.out.println(aluno.toStringAluno());
        if(aluno.media<7)
            System.out.println("Reprovado!");
        else
            System.out.println("Aprovado!");
    }
    
}
