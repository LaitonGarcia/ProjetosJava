/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package caixaeletronico;

/**
 *
 * @author GARCIA
 */
public class CaixaEletronico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // testando classe Pessoa
       Pessoa pessoa = new Pessoa();
       pessoa.setCpf("45219566600");
       pessoa.setNome("João Batista");
       pessoa.setFone("99994444");
       //System.out.print(pessoa.mostrarPessoa());
         
       // Testando Classe Conta
       Conta conta = new Conta();
       conta.setNumeroConta(11);
       conta.setSaldo(1000);
       conta.setSenha(12345);
       conta.setCliente(pessoa);
      // System.out.println(conta.mostrarConta());
       char a = 'a';
       char b = 'b';
       a=b;
       System.out.println("char a: "+a);
       System.out.println("char b: "+b);
       System.out.println(a==b);
    } // fim do main
    
}// fim classe CaixaEletronico
