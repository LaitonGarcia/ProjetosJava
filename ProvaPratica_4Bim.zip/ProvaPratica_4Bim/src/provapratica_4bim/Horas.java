/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package provapratica_4bim;

/**
 *
 * @author GARCIA
 */
public class Horas {
    private int hora;

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        if(validarHora(hora))
            this.hora = hora;
        else 
            System.out.println("Hora inválida!");
    }
    public boolean validarHora(int hora){
        return hora >= 0 && hora <=23;
    }
    public String mostrarHora(){
        return hora+":00 Hrs";
    }
} // fim da classe Horas
