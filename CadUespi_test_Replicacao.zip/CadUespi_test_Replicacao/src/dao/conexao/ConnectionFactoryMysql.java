/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author GARCIA
 */
public class ConnectionFactoryMysql {
    public static  Connection getConexao() throws SQLException {
        
        //nome do usuario do banco
        String usuario = "root";
        
        //senha do usuario do banco
        //String senha = "Sobral10*";
        //String senha = "pgadmim";
        String senha = "313231";
        
        //ip do banco. para banco no mesmo computador utilize localhost
        //String ip = "192.86.221.196";
        //String ip = "192.86.221.5";
        String ip = "localhost";
        
        //nome do banco de dados. padrao do postgre eh postgres
        String bd = "cadbiblioteca";
        
        //porta de conexao com o banco de dados. Padrao do postgre eh 5432
        int porta = 3306;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://" + ip + ":" + porta + "/" + bd, usuario, senha);
        } catch (ClassNotFoundException e) { 
            throw new SQLException(e.getMessage());
        }
        
    }
}
