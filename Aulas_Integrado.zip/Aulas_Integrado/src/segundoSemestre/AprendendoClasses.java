/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package segundoSemestre;

/**
 *
 * @author GARCIA
 */
public class AprendendoClasses {
    public static void main(String[] args) {
        System.out.println("Está Classe ainda não faz nada!");
        Calcular valor = new Calcular();
        valor.setNum1(2);
        valor.setNum2(3);
       
        System.out.println("O resultado é: " + valor.somar());
       // System.out.println("O primeiro valor é: " + valor.getNum1());
    }// Fim do Main
}// Fim da Classe AprendendoClasses
