/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package primeiroSemestre;

/**
 *
 * @author GARCIA
 */
public class Aula_2_InstrControle_operLogico {
    
    public static void main(String[] args) {
        
        
        
        
   /*     // Instrução de seleção DUPLA if...else
        
        if( 3 > 2)  // Se condição verdadeira/true
            System.out.println("VERDADE"); // imprime
        else 
            System.out.println("FALSO");
 */    
        
        
        
   /*  
        
        if(11 > -11)  // Se condição Falsa/falsa
            System.out.println("VERDADE");
        else
            System.out.println("FALSO");  // imprime
     */   
      
        
        
        
        
        
        
      
 /*       
        if( 4 > 2){  // Para blocos de instrução colocar entre { }
            System.out.println("VERDADE");
            System.out.println("Mas poderia ser falso!");
            if(2 != 2){
                System.out.println("O Três é diferente de Dois");
                System.out.println("Testando as chaves");
            }
        }
        else 
            System.out.println("FALSO"); 
        
   */   
        
        
/*        
        
        if( 2 > 4)  // Instruções if...else Aninhadas
            System.out.println("Primeiro maior Segundo");
        else 
            if(4 < 2) 
                System.out.println("Primeiro < Segundo");
            else 
                if(3 != 3) 
                    System.out.println("São diferentes");
                else 
                    if(2 == 2){ // Com bloco de instrução
                        System.out.println("Primeiro igual Segundo");
                        System.out.println("Verdade");
                    }
                    else
                        System.out.println("Nenhuma Foi Verdadeira!");
       
            
      
        if( 2 > 4)  // Instruções if...else Aninhadas
            System.out.println("Primeiro maior Segundo");
        else if(4 < 2) 
            System.out.println("Primeiro < Segundo");
        else if(3 != 3)
            System.out.println("São diferentes");
        else if(2 == 2){ // Com bloco de instrução
            System.out.println("Primeiro igual Segundo");
            System.out.println("Verdade");
            }
        else
            System.out.println("Nenhuma Foi Verdadeira!");
    */  
   /*     
        int x = 6;
        int y = 9;
        
        if(x > 7)
            if(y > 7)
                System.out.println("x e y são > 7");
        else
            System.out.println("x é <= 7");
    */    
        
        
   /*     
        
        
        
        
        if(x > 7)
            if(y > 7)
                System.out.println("x e y são > 7");
            else
                System.out.println("x é <= 7");
        
        
        
        if(x > 7){
            if(y > 7)
                System.out.println("x e y são > 7");
        }   
        else
            System.out.println("x é <= 7");
       
     */   
           
       
  /*
        int x = 5;
        int y = 5;
        if (x >= y)System.out.println("instruçãoA");
        
        if(x > y || x == y)System.out.println("instruçãoB");
        
        if(x > y || x < y); System.out.println("instruçãoC");
        
        if(x > y && y > x) System.out.println("instruçãoD");
        
        if(x > y || y > x) System.out.println("instruçãoE");
        
        if(x == y || y == x) System.out.println("instruçãoF");
        
        if(x >= y && x <= y && x == y) System.out.println("instruçãoG");
        
        if(x >= y || x <= y || x == y)System.out.println("instruçãoH");
        
      // if(x) System.out.println("instruçãoI");
       //    else System.out.println("instruçãoJ");
        
        if(x >= y || x <= y || x == y) System.out.println("instruçãoK");
            else System.out.println("instruçãoL");
        
        if(x > y && x < y) System.out.println("instruçãoM");
            else System.out.println("instruçãoN");
        
     
        
        if(x > y) System.out.println("instruçãoO");
            else if(x < y) System.out.println("instruçãoP");
                else if(x != y) System.out.println("instruçãoQ");
                    else if(x == y){ 
                        System.out.println("instruçãoR");
                        System.out.println("intruçãoS");
                        }else { 
                              System.out.println("instruçãoT");
                        } 
        
        if(x != y){
            System.out.println("instruçãoU");
            System.out.println("instruçãoV");
        }else 
            System.out.println("instruçãoX");
        
        if(x != y || x == y || x > y || x < y || x >= y || x <= y)
            System.out.println("instruçãoY"); 
        else 
            System.out.println("instruçãoZ");
        
        if(x != y && x == y && x > y && x < y && x >= y && x <= y)
            System.out.println("instruçãoZ");
        else
            System.out.println("instruçãoW");
        
        if(x == y && x > y && x < y && x >= y && x <= y || x != y)
            System.out.println("instruçãoXY");
        else
            System.out.println("instruçãoAB");  
       
      // x =  x!=y ?  6:7;
      
      */ 
        
    
    } // Fim do metodo main()
    
} // }Fim da Classe Aula_2_InstrControle_operLogico
