/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package iniciandoclasse;

/**
 *
 * @author GARCIA
 */
public class Pessoa {
    private String nome;
    private String sexo;
    private int idade;
    private String cpf;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public void mostrarPessoa(){
        System.out.println("Nome: "+this.nome+" idade: "+this.idade);
        System.out.println("Cpf: "+this.cpf+" sexo: "+this.sexo);
    }
    
}// fim classe pessoa
