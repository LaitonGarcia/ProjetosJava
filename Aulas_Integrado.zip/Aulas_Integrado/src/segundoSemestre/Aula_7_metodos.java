/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package segundoSemestre;

import java.util.Scanner;

/**
 *
 * @author GARCIA
 */
public class Aula_7_metodos {
    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double num1 = 0;
        double num2 = 0;
        double result;
        String opcao = null;
        do{
            do{ 
                System.out.println("Escolha a opção: \n + Adição; \n - Subtração");
                System.out.println(" * Multiplicação \n / Divisão;");
                opcao = entrada.nextLine();
            }while(!(opcao.equals("+")||opcao.equals("-")||opcao.equals("*")||opcao.equals("/")||opcao.equals("s")));
            
            if(!opcao.equals("s")){
                System.out.println("Digite o primeiro numero para ser calculado");
                num1 = entrada.nextDouble();
                System.out.println("Digite o segundo numero para ser calculado");      
                num2 = entrada.nextDouble();
            }
          
            switch(opcao){
                case "+": 
                         adicao(num1,num2);
                         entrada.nextLine();
                         break;
                case "-":
                         result= subtracao(num1,num2);
                         System.out.println(result);
                         entrada.nextLine();
                         break;
                case "*":
                         System.out.println("O resultado da operação é:"+(num1*num2));
                         entrada.nextLine();
                         break;
                case "/":
                         System.out.println("O resultado da operação é:"+(num1/num2));
                         entrada.nextLine();
                         break;
                case "s":
                    System.out.println("Muito obrigado por usar nosso serviço!");
              } // Fim do Switch      
        } while(!(opcao.equals("s")));
      } // fim do main  
   
    public static void adicao(double n1, double n2){
        System.out.println("O resultado da operação é:"+(n1+n2));
    } // fim metodo adição
    
    public static double subtracao(double n1,double n2){
        return n1-n2;
    } // fim metodo subtração
} // fim da classe
