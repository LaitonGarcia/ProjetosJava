package replicar;
// Sequência da replicação Aluno:
// na tela.Principal.Principal() é chamada o metodo Replicar.Replicar() para inicializar a replicação;
// em seguida é novamente chamada a função Replicar.Replicar() num loop a cada minuto;
// a função Replicar.Replicar() primeiro testa as conexões com os Bancos de Dados atravez das
// conexoes ConnectionFactoryCliente e ConnectionFactoryServidor liberando o metodo pesquisarInsertReplicacao() 
// para fazer uma consulta na tabela insert_replicacao no BD servidor trazendo um vetor de CpfReplicacao 
// para que o metodo fazerInsertReplicacao() processe os Cpfs em função de seu tipo_pessoa;
// o metodo alunoDAO.pesquisarAlunoComMatricula(i.getCpf()) trás do BD servidor um Aluno pra ser cadastrado/copiado
// no BD cliente pelo metodo cadastrarAlunoCliente(). Após o cadastramento verifica-se se houve alguma excecao,
// caso sim está excecao é registrada na tabela excecoes_replicacao no BD servidor pelo metodo gravarExcecoes()
// a ser tratado manualmente, em ambos os casos o CPF replicado será deletado da tabela insert_replicacao 
// pelo metodo limparInsertReplicacao(aluno.getCpf()) no BD servidor para evitar redundâncias.

import dao.AlunoDAO;
import dao.DependenteDAO;
import dao.FormacaoDAO;
import dao.MetodosBD;
import dao.ProfessorDAO;
import dao.conexao.ConnectionFactory;
import dao.conexao.ConnectionFactoryBackup;
import dao.conexao.ConnectionFactoryCliente;
import dao.conexao.ConnectionFactoryMysql;
import dao.conexao.ConnectionFactoryOracle;
import entidades.Aluno;
import entidades.CpfReplicar;
import entidades.Dependentes;
import entidades.Formacao;
import entidades.Professor;
import entidades.util.Endereco;
import entidades.util.Rg;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Replicar {

    /*   // Somente pra fazer demonstração de replicação manualmente 'setando' da tela principal
     public void cpf(String cpf) throws SQLException{
     AlunoDAO alunoDAO = new AlunoDAO();
     Aluno aluno;
     aluno = alunoDAO.pesquisarAlunoComMatricula(cpf);
     cadastrarAlunoCliente(aluno);
     };
     */
    public void updateAuxiliarAlunosWeb() throws SQLException {
        apagarDadosDaAuxiliarWeb();
    }

    public void apagarDadosDaAuxiliarWeb() throws SQLException {
        String sql = "truncate auxiliar_alteracao_web;";
        PreparedStatement ps = ConnectionFactoryMysql.getConexao().prepareStatement(sql);
        ps.executeUpdate();
        ConnectionFactoryMysql.getConexao().close();
    }
    /* Consultar na WEB registros na tabela auxiliar_alteracao_web e Trazer vetor de Alunos que solicitaram alteraçao */
    public ArrayList<Aluno> pesquisarAlunosComPendencias() throws SQLException { // FALTA TESTAR
              System.out.println(" buscarAlunosDaWeb Aluno nome:");
        System.out.println("buscarAlunosDaWeb Aluno tipo pessoa:");
        ResultSet res;
        String sql = "select * from auxiliar_alteracao_web";
        PreparedStatement ps = ConnectionFactoryMysql.getConexao().prepareStatement(sql);
        ArrayList<Aluno> vetorAluno = new ArrayList<>();
        res = ps.executeQuery();
        try {
            while (res.next()) {
                Aluno aluno = new Aluno();
                Rg rg = new Rg();
                rg.setRg(res.getString("rg"));
                rg.setRgOrgaoEmissor(res.getString("rg_orgao_emissor"));
                rg.setRgOrgaoEmissorUf(res.getString("rg_orgao_emissor_uf"));
                aluno.setRg(rg);
                aluno.setCpf(res.getString("cpf"));
                aluno.setNome(res.getString("nome"));
                aluno.setDataNascimento(res.getDate("data_nascimento"));
                aluno.setEstadoCivil(res.getString("estado_civil"));
                aluno.setSexo(res.getString("sexo"));
                aluno.setFiliacaoMae(res.getString("filiacao_mae"));
                aluno.setFiliacaoPai(res.getString("filiacao_pai"));
                aluno.setEmail(res.getString("email"));
                aluno.setTelefone1(res.getString("telefone_1"));
                aluno.setTelefone2(res.getString("telefone_2"));
                Endereco endereco = new Endereco();
                endereco.setEndereco(res.getString("endereco"));
                endereco.setNumero(res.getString("numero"));
                endereco.setBairro(res.getString("bairro"));
                endereco.setMunicipio(res.getString("municipio"));
                endereco.setUf(res.getString("uf"));
                endereco.setCep(res.getString("cep"));
                aluno.setEndereco(endereco);
                aluno.setTipoPessoa(res.getString("tipo_pessoa"));
                vetorAluno.add(aluno);
                System.out.println("Pesquisando alunos com pendencias: "+aluno.getNome());
            }
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        ConnectionFactoryMysql.getConexao().close();
        return vetorAluno;
    }

    /* Registrar no BD LOCAL na tabela auxiliar_web_local a solicitação de Alunos via WEB para alteração de Dados manual */
    public void cadastrarAlunoAuxiliarWebLocal(Aluno aluno) { 
        String sql = "insert into auxiliar_web_local (cpf,nome,senha,rg,rg_orgao_emissor,rg_orgao_emissor_uf,"
                + "data_nascimento,estado_civil,sexo, filiacao_mae,filiacao_pai,"
                + "email, telefone_1, telefone_2, endereco, numero, bairro,municipio, uf, cep,tipo_pessoa)"
                + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
            ps.setString(1, aluno.getCpf());
            ps.setString(2, aluno.getNome());
            ps.setString(3, aluno.getSenha());
            ps.setString(4, aluno.getRg().getRg());
            ps.setString(5, aluno.getRg().getRgOrgaoEmissor());
            ps.setString(6, aluno.getRg().getRgOrgaoEmissorUf());
            ps.setDate(7,new java.sql.Date( aluno.getDataNascimento().getTime()));
            ps.setString(8, aluno.getEstadoCivil());
            ps.setString(9, aluno.getSexo());
            ps.setString(10, aluno.getFiliacaoMae());
            ps.setString(11, aluno.getFiliacaoPai());
            ps.setString(12, aluno.getEmail());
            ps.setString(13, aluno.getTelefone1());
            ps.setString(14, aluno.getTelefone2());
            ps.setString(15, aluno.getEndereco().getEndereco());
            ps.setString(16, aluno.getEndereco().getNumero());
            ps.setString(17, aluno.getEndereco().getBairro());
            ps.setString(18, aluno.getEndereco().getMunicipio());
            ps.setString(19, aluno.getEndereco().getUf());
            ps.setString(20, aluno.getEndereco().getCep());
            ps.setString(21, aluno.getTipoPessoa());
            ps.executeUpdate();

            ConnectionFactory.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /* Metodo recebe Vetor de Alunos da WEB que solicitaram alterações cadastrais e registra na tabela auxiliar_web_local */
    public void buscarAlunosDaWeb(ArrayList<Aluno> alunos) throws SQLException {

        for (Aluno i : alunos) {
                cadastrarAlunoAuxiliarWebLocal(i); // Quando outros tipos forem usados apagar essa linha
          /*  
            if (i.getTipoPessoa().equals("aluno")) {
                cadastrarAlunoAuxiliarWebLocal(i);
            }
            if (i.getTipoPessoa().equals("professor")) {
            }
            if (i.getTipoPessoa().equals("professor_temporario")) {
            }
            if (i.getTipoPessoa().equals("terceirizado")) {
            }
            if (i.getTipoPessoa().equals("servidor")) {
            }
         */   
        }
        updateAuxiliarAlunosWeb();
    }
    
    /* Metodo que Cadastra novo Aluno no BD WEB */
    public void cadastrarAlunoNaWeb(Aluno aluno) throws SQLException {
        String sql = "insert into aluno (cpf, nome, senha, rg, rg_orgao_emissor, rg_orgao_emissor_uf,"
                + "data_nascimento, estado_civil, sexo, filiacao_mae, filiacao_pai, email, telefone_1, "
                + "telefone_2, endereco, numero, bairro, municipio, uf, cep, tipo_pessoa)"
                + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = ConnectionFactoryMysql.getConexao().prepareStatement(sql);
            ps.setString(1, aluno.getCpf());
            ps.setString(2, aluno.getNome());
            ps.setString(3,aluno.getSenha());
            ps.setString(4, aluno.getRg().getRg());
            ps.setString(5, aluno.getRg().getRgOrgaoEmissor());
            ps.setString(6, aluno.getRg().getRgOrgaoEmissorUf());
            ps.setDate(7, new java.sql.Date(aluno.getDataNascimento().getTime()));
            ps.setString(8, aluno.getEstadoCivil());
            ps.setString(9, aluno.getSexo());
            ps.setString(10, aluno.getFiliacaoMae());
            ps.setString(11, aluno.getFiliacaoPai());
            ps.setString(12, aluno.getEmail());
            ps.setString(13, aluno.getTelefone1());
            ps.setString(14, aluno.getTelefone2());
            ps.setString(15, aluno.getEndereco().getEndereco());
            ps.setString(16, aluno.getEndereco().getNumero());
            ps.setString(17, aluno.getEndereco().getBairro());
            ps.setString(18, aluno.getEndereco().getMunicipio());
            ps.setString(19, aluno.getEndereco().getUf());
            ps.setString(20, aluno.getEndereco().getCep());
            ps.setString(21, aluno.getTipoPessoa());
            ps.executeUpdate();
            ConnectionFactoryMysql.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
            gravarExcecoes(aluno.getCpf(), aluno.getTipoPessoa(), ex.getMessage(), ex.toString());
            System.out.println("SQL Provider:W " + ex.getErrorCode());
            // o metodo getSQLState é inicializado com null, então armazenar CPF pra analise Manual
            //if(ex.getSQLState()!= null)System.out.println(" AQUI instrução PARA ARMAZENAR ESTE cpf PARA ANALISE ");
                /*System.out.println("SQL Exception:W " + ex.getMessage()); 
             System.out.println("SQL outro: W " + ex.getLocalizedMessage()+ "outro 1 W "+ ex.toString()+ "outro 2 W "+ ex.getCause()+ "outro 3 W "+ ex.getClass());
             System.out.println("SQL Estado: W " + ex.getSQLState());
             System.out.println("SQL Provider:W " + ex.getErrorCode());
             System.out.println(" FIM do que EU quero ");
             System.out.println("SQL Exception:W " + ex.getMessage());*/

            /*if(ex.getErrorCode()!= 1)System.out.println("Code ALUNO NÂO CADASTRADO E INSERIDO ANALISE MANUAL");
             if(ex.getMessage()!= null)System.out.println("Message ALUNO NÂO CADASTRADO E INSERIDO ANALISE MANUAL");
             System.out.println("SQL Provider:" + ex.getErrorCode());
             System.out.println("ESTE ALUNO NÂO FOI CADASTRADO:" + aluno.getNome());
             System.out.println("SQL Exception:" + ex.getMessage()); 
             System.out.println("SQL Estado:" + ex.getSQLState());
             System.out.println("SQL Provider:" + ex.getErrorCode());
             System.out.println("FIM do que EU quero");*/
        }
        limparInsertReplicacao(aluno.getCpf());
    }
    
    /* Metodo que Atualiza dados de Aluno no BD WEB */
    public void atualizarAlunoNaWeb(Aluno aluno, String cpfAntigo) throws SQLException {

        String sql = "update aluno set cpf=?, nome=?, senha=?, rg=?, rg_orgao_emissor=?, rg_orgao_emissor_uf=?,"
                + "data_nascimento=? , estado_civil=?, sexo=?, filiacao_mae=?, filiacao_pai=?, email=?, "
                + "telefone_1=?, telefone_2=?, endereco=?, numero=?, bairro=?, municipio=?, uf=?, cep=? where cpf=?";
        try {
            PreparedStatement ps = ConnectionFactoryMysql.getConexao().prepareStatement(sql);
            ps.setString(1, aluno.getCpf());
            ps.setString(2, aluno.getNome());
            ps.setString(3,aluno.getSenha());
            ps.setString(4, aluno.getRg().getRg());
            ps.setString(5, aluno.getRg().getRgOrgaoEmissor());
            ps.setString(6, aluno.getRg().getRgOrgaoEmissorUf());
            ps.setDate(7, new java.sql.Date(aluno.getDataNascimento().getTime()));
            ps.setString(8, aluno.getEstadoCivil());
            ps.setString(9, aluno.getSexo());
            ps.setString(10, aluno.getFiliacaoMae());
            ps.setString(11, aluno.getFiliacaoPai());
            ps.setString(12, aluno.getEmail());
            ps.setString(13, aluno.getTelefone1());
            ps.setString(14, aluno.getTelefone2());
            ps.setString(15, aluno.getEndereco().getEndereco());
            ps.setString(16, aluno.getEndereco().getNumero());
            ps.setString(17, aluno.getEndereco().getBairro());
            ps.setString(18, aluno.getEndereco().getMunicipio());
            ps.setString(19, aluno.getEndereco().getUf());
            ps.setString(20, aluno.getEndereco().getCep());
            ps.setString(21, cpfAntigo);
            ps.executeUpdate();
            ConnectionFactoryMysql.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
            gravarExcecoes(aluno.getCpf(), aluno.getTipoPessoa(), ex.getMessage(), ex.toString());
            System.out.println("SQL Provider:W " + ex.getErrorCode());
        }
        limparUpdateReplicacao(aluno.getCpf());
    }

/* XXXXXXXXXX  FIM REPLICAÇÃO WEB   XXXXXXXXXXX  FIM REPLICAÇÃO WEB XXXXXXXXXXXXXXXXX */    
    public void cadastrarAlunoCliente(Aluno aluno) throws SQLException {
        String sql = "insert into aluno (cpf,nome,rg,rg_orgao_emissor,rg_orgao_emissor_uf,rg_data_emissao,"
                + "data_nascimento,nacionalidade,naturalidade,naturalidade_uf,estado_civil,sexo,grau_escolaridade,"
                + "titulo_eleitor, titulo_eleitor_secao, titulo_eleitor_zona, titulo_eleitor_uf,"
                + "titulo_eleitor_data_emissao,certificado_militar_numero,certificado_militar_tipo, "
                + "certificado_militar_serie, certificado_militar_categoria,certificado_militar_csm, "
                + "certificado_militar_rm, grupo_sanguineo, fator_rh, filiacao_mae, filiacao_pai, "
                + "email, telefone_1, telefone_2, endereco, numero, bairro,municipio,uf,cep,tipo_pessoa)"
                + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = ConnectionFactoryCliente.getConexao().prepareStatement(sql);
            ps.setString(1, aluno.getCpf());
            ps.setString(2, aluno.getNome());
            ps.setString(3, aluno.getRg().getRg());
            ps.setString(4, aluno.getRg().getRgOrgaoEmissor());
            ps.setString(5, aluno.getRg().getRgOrgaoEmissorUf());
            ps.setDate(6, new java.sql.Date(aluno.getRg().getRgDataEmissao().getTime()));
            ps.setDate(7, new java.sql.Date(aluno.getDataNascimento().getTime()));
            ps.setString(8, aluno.getNacionalidade());
            ps.setString(9, aluno.getNaturalidade());
            ps.setString(10, aluno.getNaturalidadeUf());
            ps.setString(11, aluno.getEstadoCivil());
            ps.setString(12, aluno.getSexo());
            ps.setString(13, aluno.getGrauEscolaridade());
            ps.setString(14, aluno.getTituloEleitor().getTituloEleitor());
            ps.setString(15, aluno.getTituloEleitor().getTituloEleitorSecao());
            ps.setString(16, aluno.getTituloEleitor().getTituloEleitorZona());
            ps.setString(17, aluno.getTituloEleitor().getTituloEleitorUf());
            ps.setDate(18, new java.sql.Date(aluno.getTituloEleitor().getTituloEleitorDataEmissao().getTime()));
            ps.setString(19, aluno.getCertificadoMilitar().getCertificadoMilitarNumero());
            ps.setString(20, aluno.getCertificadoMilitar().getCertificadoMilitarTipo());
            ps.setString(21, aluno.getCertificadoMilitar().getCertificadoMilitarSerie());
            ps.setString(22, aluno.getCertificadoMilitar().getCertificadoMilitarCategoria());
            ps.setString(23, aluno.getCertificadoMilitar().getCertificadoMilitarCsm());
            ps.setString(24, aluno.getCertificadoMilitar().getCertificadoMilitarRm());
            ps.setString(25, aluno.getGrupoSanguineo());
            ps.setString(26, aluno.getFatorRh());
            ps.setString(27, aluno.getFiliacaoMae());
            ps.setString(28, aluno.getFiliacaoPai());
            ps.setString(29, aluno.getEmail());
            ps.setString(30, aluno.getTelefone1());
            ps.setString(31, aluno.getTelefone2());
            ps.setString(32, aluno.getEndereco().getEndereco());
            ps.setString(33, aluno.getEndereco().getNumero());
            ps.setString(34, aluno.getEndereco().getBairro());
            ps.setString(35, aluno.getEndereco().getMunicipio());
            ps.setString(36, aluno.getEndereco().getUf());
            ps.setString(37, aluno.getEndereco().getCep());
            ps.setString(38, aluno.getTipoPessoa());
            ps.executeUpdate();
            ConnectionFactoryCliente.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
            gravarExcecoes(aluno.getCpf(), aluno.getTipoPessoa(), ex.getMessage(), ex.toString());
            System.out.println("SQL Provider:W " + ex.getErrorCode());
            // o metodo getSQLState é inicializado com null, então armazenar CPF pra analise Manual
            //if(ex.getSQLState()!= null)System.out.println(" AQUI instrução PARA ARMAZENAR ESTE cpf PARA ANALISE ");
                /*System.out.println("SQL Exception:W " + ex.getMessage()); 
             System.out.println("SQL outro: W " + ex.getLocalizedMessage()+ "outro 1 W "+ ex.toString()+ "outro 2 W "+ ex.getCause()+ "outro 3 W "+ ex.getClass());
             System.out.println("SQL Estado: W " + ex.getSQLState());
             System.out.println("SQL Provider:W " + ex.getErrorCode());
             System.out.println(" FIM do que EU quero ");
             System.out.println("SQL Exception:W " + ex.getMessage());*/

            /*if(ex.getErrorCode()!= 1)System.out.println("Code ALUNO NÂO CADASTRADO E INSERIDO ANALISE MANUAL");
             if(ex.getMessage()!= null)System.out.println("Message ALUNO NÂO CADASTRADO E INSERIDO ANALISE MANUAL");
             System.out.println("SQL Provider:" + ex.getErrorCode());
             System.out.println("ESTE ALUNO NÂO FOI CADASTRADO:" + aluno.getNome());
             System.out.println("SQL Exception:" + ex.getMessage()); 
             System.out.println("SQL Estado:" + ex.getSQLState());
             System.out.println("SQL Provider:" + ex.getErrorCode());
             System.out.println("FIM do que EU quero");*/
        }
        limparInsertReplicacao(aluno.getCpf());
    }

// Metodo que cadastra os usuarios na biblioteca
    public void cadastrarPessoaBiblioteca(Aluno aluno) throws SQLException {
        String sql = "insert into usuario(cpf, matricula, nome_completo, nome_usuario, senha, categoria_usuario,"
                + "cargo, sexo, logradouro, numero, bairro,"
                + "cidade, UF, telefone, email) "
                + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        //PreparedStatement ps = ConnectionFactoryCliente.getConexao().prepareStatement(sql);
        //PreparedStatement ps = ConnectionFactoryOracle.getConexao().prepareStatement(sql);// Abrir conexão BD Oracle
        PreparedStatement ps = ConnectionFactoryMysql.getConexao().prepareStatement(sql);// Abrir conexão BD MySql
        try {

            ps.setString(1, aluno.getCpf());// cpf
            ps.setString(2, "matri"); //matricula
            ps.setString(3, aluno.getNome()); // nome
            ps.setString(4, "loginusuario");  // nome usuario
            ps.setString(5, "senha"); // senha
            ps.setString(6, aluno.getTipoPessoa());//categoria
            ps.setString(7, aluno.getCurso().nome); // cargo
            ps.setString(8, aluno.getSexo()); // sexo
            ps.setString(9, aluno.getEndereco().getEndereco()); // endereço, logradouro
            ps.setString(10, aluno.getEndereco().getNumero());// numero
            ps.setString(11, aluno.getEndereco().getBairro()); //bairro
            ps.setString(12, aluno.getEndereco().getMunicipio()); // municipio, cidade
            ps.setString(13, aluno.getEndereco().getUf());
            ps.setString(14, aluno.getTelefone1());
            ps.setString(15, aluno.getEmail());

            ps.executeUpdate();
            //ConnectionFactoryCliente.getConexao().close();
            ConnectionFactoryOracle.getConexao().close();  // Encerrar conexão BD Oracle 
            //ConnectionFactoryMysql.getConexao().close();  // Encerrar conexão BD MySql
        } catch (SQLException ex) {
            gravarExcecoes(aluno.getCpf(), aluno.getTipoPessoa(), ex.getMessage(), ex.toString());
            System.out.println("Erro ao inserir " + ex.getMessage());
        }
        //limparInsertReplicacao(aluno.getCpf());
    }

    // metodo para cadastrar professor no BD cliente e tambem os metodos cadastrar com seus dependentes e formação
    public void cadastrarProfessorCliente(Professor professor) throws SQLException { // FALTA TESTAR
        DependenteDAO dependenteDAO = new DependenteDAO();
        FormacaoDAO formacaoDAO = new FormacaoDAO();
        String sql = "insert into professor (cpf,nome,rg,rg_orgao_emissor,rg_orgao_emissor_uf,rg_data_emissao,"
                + "data_nascimento,nacionalidade,naturalidade,naturalidade_uf,estado_civil,sexo,grau_escolaridade,"
                + "titulo_eleitor, titulo_eleitor_secao, titulo_eleitor_zona, titulo_eleitor_uf,titulo_eleitor_data_emissao,"
                + "certificado_militar_numero,certificado_militar_tipo, certificado_militar_serie, "
                + "certificado_militar_categoria,certificado_militar_csm, certificado_militar_rm, grupo_sanguineo, fator_rh,"
                + "filiacao_mae, filiacao_pai, email, telefone_1, telefone_2, endereco, numero, bairro,municipio,uf,cep, tipo_pessoa,"
                + "pis,pis_data_inscricao,carteira_trabalho,carteira_trabalho_serie, carteira_trabalho_uf, carteira_trabalho_data_emissao,"
                + "cnh,cnh_categoria, cnh_data_emissao, conjuge, conjuge_cpf ) "
                + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = ConnectionFactoryCliente.getConexao().prepareStatement(sql);
            ps.setString(1, professor.getCpf());
            ps.setString(2, professor.getNome());
            ps.setString(3, professor.getRg().getRg());
            ps.setString(4, professor.getRg().getRgOrgaoEmissor());
            ps.setString(5, professor.getRg().getRgOrgaoEmissorUf());
            ps.setDate(6, new java.sql.Date(professor.getRg().getRgDataEmissao().getTime()));
            ps.setDate(7, new java.sql.Date(professor.getDataNascimento().getTime()));
            ps.setString(8, professor.getNacionalidade());
            ps.setString(9, professor.getNaturalidade());
            ps.setString(10, professor.getNaturalidadeUf());
            ps.setString(11, professor.getEstadoCivil());
            ps.setString(12, professor.getSexo());
            ps.setString(13, professor.getFormacao());
            ps.setString(14, professor.getTituloEleitor().getTituloEleitor());
            ps.setString(15, professor.getTituloEleitor().getTituloEleitorSecao());
            ps.setString(16, professor.getTituloEleitor().getTituloEleitorZona());
            ps.setString(17, professor.getTituloEleitor().getTituloEleitorUf());
            ps.setDate(18, new java.sql.Date(professor.getTituloEleitor().getTituloEleitorDataEmissao().getTime()));
            ps.setString(19, professor.getCertificadoMilitar().getCertificadoMilitarNumero());
            ps.setString(20, professor.getCertificadoMilitar().getCertificadoMilitarTipo());
            ps.setString(21, professor.getCertificadoMilitar().getCertificadoMilitarSerie());
            ps.setString(22, professor.getCertificadoMilitar().getCertificadoMilitarCategoria());
            ps.setString(23, professor.getCertificadoMilitar().getCertificadoMilitarCsm());
            ps.setString(24, professor.getCertificadoMilitar().getCertificadoMilitarRm());
            ps.setString(25, professor.getGrupoSanguineo());
            ps.setString(26, professor.getFatorRh());
            ps.setString(27, professor.getFiliacaoMae());
            ps.setString(28, professor.getFiliacaoPai());
            ps.setString(29, professor.getEmail());
            ps.setString(30, professor.getTelefone1());
            ps.setString(31, professor.getTelefone2());
            ps.setString(32, professor.getEndereco().getEndereco());
            ps.setString(33, professor.getEndereco().getNumero());
            ps.setString(34, professor.getEndereco().getBairro());
            ps.setString(35, professor.getEndereco().getMunicipio());
            ps.setString(36, professor.getEndereco().getUf());
            ps.setString(37, professor.getEndereco().getCep());
            ps.setString(38, professor.getTipoPessoa());
            ps.setString(39, professor.getPis());
            ps.setDate(40, new java.sql.Date(professor.getPisDataInscricao().getTime()));
            ps.setString(41, professor.getCarteiraTrabalho());
            ps.setString(42, professor.getCarteiraTrabalhoSerie());
            ps.setString(43, professor.getCarteiraTrabalhoUf());
            ps.setDate(44, new java.sql.Date(professor.getCarteiraTrabalhoDataEmissao().getTime()));
            ps.setString(45, professor.getCnh());
            ps.setString(46, professor.getCnhCategoria());
            ps.setDate(47, new java.sql.Date(professor.getCnhDataEmissao().getTime()));
            ps.setString(48, professor.getConjuge());
            ps.setString(49, professor.getConjugeCpf());
            ps.executeUpdate();
            ConnectionFactoryCliente.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            gravarExcecoes(professor.getCpf(), professor.getTipoPessoa(), ex.getMessage(), ex.toString());
            System.out.println("SQL Provider:W " + ex.getErrorCode());
        }

        for (int i = 0; i < professor.getVetorDisciplina().size(); i++) {
            MetodosBD metodosBD = new MetodosBD();
            String sqlMinistra = "insert into disciplina_professor(id_disciplina,cpf) values(" + professor.getVetorDisciplina().get(i).id + ",'" + professor.getCpf() + "');";
            metodosBD.executarInstrucao(sqlMinistra);
            System.out.println(sqlMinistra);
        }
        dependenteDAO.cadastrarDependentesProfessor(professor);
        cadastrarRelacaoDependentesProfessor(professor);
        formacaoDAO.cadastrarFormacaoProfessor(professor);
        cadastrarRelacaoFormacaoProfessor(professor);
        if (professor.getMatricula() != null) {
            professor.cadastrarMatricula(professor);
        }
        limparInsertReplicacao(professor.getCpf());

    }

    // metodo cadastrar os dependentes do professor
    public void cadastrarRelacaoDependentesProfessor(Professor professor) {
        DependenteDAO dependenteDAO = new DependenteDAO();
        String sqlCadastrarRelacaoDependentesProfessor = "insert into dependente_professor(cpf, id_dependente) values(?,?);";
        for (int i = 0; i < professor.getVetorDependentes().size(); i++) {
            try {
                Dependentes dependentes = new Dependentes();
                dependentes = dependenteDAO.pesquisarDependente(professor.getVetorDependentes().get(i).nome, new java.sql.Date(professor.getVetorDependentes().get(i).dataNascimento.getTime()));
                PreparedStatement ps = ConnectionFactoryCliente.getConexao().prepareStatement(sqlCadastrarRelacaoDependentesProfessor);
                ps.setString(1, professor.getCpf());
                ps.setInt(2, dependentes.idDependente);
                ps.executeUpdate();
                ConnectionFactoryCliente.getConexao().close();
            } catch (SQLException ex) {
                Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    // metodo para cadastrar a formação do professor
    public void cadastrarRelacaoFormacaoProfessor(Professor professor) {
        FormacaoDAO formacaoDAO = new FormacaoDAO();
        String sqlCadastrarRelacaoFormacaoProfessor = "insert into formacao_professor(id_formacao, cpf) values(?,?);";
        for (int i = 0; i < professor.getVetorFormacao().size(); i++) {
            try {
                Formacao formacao = formacaoDAO.pesquisarFormacao(professor.getVetorFormacao().get(i).nome, professor.getCpf());
                PreparedStatement ps = ConnectionFactoryCliente.getConexao().prepareStatement(sqlCadastrarRelacaoFormacaoProfessor);
                ps.setLong(1, formacao.id);
                ps.setString(2, professor.getCpf());
                ps.executeUpdate();
                ConnectionFactoryCliente.getConexao().close();
            } catch (SQLException ex) {
                Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    // Metodo que registra as exceções com seu motivo, a ser tratado manualmente pelo DBA
    // Invocado no metodo Replicar.cadastrarAlunoCliente em SQLException que envia o CPF,
    // tipoPessoa e mensagem de exceçao e registrados na tabela excecoes_replicacao
    public void gravarExcecoes(String cpf, String tipoPessoa, String excecao, String bancoDeDados) {
        // registrando as exceções
        String sql = "insert into excecoes_replicacao (cpf,tipo_pessoa, mensagem_excecao,banco_de_dados )"
                + "values(?,?,?,?)";
        try {
            PreparedStatement ps = ConnectionFactoryBackup.getConexao().prepareStatement(sql);
            ps.setString(1, cpf);
            ps.setString(2, tipoPessoa);
            ps.setString(3, excecao);
            ps.setString(4, bancoDeDados);
            ps.executeUpdate();
            ConnectionFactoryBackup.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
        }
        /*     // testando importação de dados
         System.out.println("CPF: " + cpf);
         System.out.println("Tipo de Pessoa: " + tipoPessoa);
         System.out.println("Mensagem exceção: " + excecao);
        /*     // testando importação de dados
         System.out.println("CPF: " + cpf);
         System.out.println("Tipo de Pessoa: " + tipoPessoa);
         System.out.println("Mensagem exceção: " + excecao);
         */
    }

    // Metodo que registra exceções no update, Invocado pelo metodo fazerUpdateReplicacao
    // quando CPF_OLD não existe no BD destino a alteração não pode ser registrada, então
    // registra-se na tabela excecoes_replicacao a ser tratado manualmente pelo DBA
    public void gravarExcecoes(CpfReplicar cpfUpdateExcecao) {
        // registrando as exceções, neste caso dos CPF_OLD não encontrado no BD destino
        String sql = "insert into excecoes_replicacao (cpf, cpf_old, tipo_pessoa, mensagem_excecao )"
                + "values(?,?,?,?)";
        try {
            PreparedStatement ps = ConnectionFactoryBackup.getConexao().prepareStatement(sql);
            ps.setString(1, cpfUpdateExcecao.getCpf());
            ps.setString(2, cpfUpdateExcecao.getCpfOld());
            ps.setString(3, cpfUpdateExcecao.getTipoPessoa());
            ps.setString(4, "CPF OLD não existe no BD destino para ser alterado!");
            ps.executeUpdate();
            ConnectionFactoryBackup.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
        }
        /*     // testando importação de dados
         System.out.println("CPFexcecao " + cpfUpdateExcecao.getCpf());
         System.out.println("CPF OLDexcecao " + cpfUpdateExcecao.getCpfOld());
         System.out.println("TIPO PESSOAexcecao " + cpfUpdateExcecao.getTipoPessoa());
         System.out.println("CPF OLD não existe no BD destino para ser alterado!");
        /*     // testando importação de dados
         System.out.println("CPFexcecao " + cpfUpdateExcecao.getCpf());
         System.out.println("CPF OLDexcecao " + cpfUpdateExcecao.getCpfOld());
         System.out.println("TIPO PESSOAexcecao " + cpfUpdateExcecao.getTipoPessoa());
         System.out.println("CPF OLD não existe no BD destino para ser alterado!");
         */
    }

    // Metodo que limpa a tabela insert_replicacao no BD servidor para evitar
    // redundâncias de dados que criariam exceções na replicação de dados, restrição 
    // de unicidade de chave primaria(PK) do BD
    // chamado pelo metodo Replicar.cadastrarAlunoCliente com um CPF após tratamento de exceções
    public void limparInsertReplicacao(String cpf) {
        // comando delete pelo CPF
        String sql = "delete from insert_replicacao where cpf = ?;";
        try {
            PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
            ps.setString(1, cpf);
            ps.executeUpdate();
            ConnectionFactory.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void limparUpdateReplicacao(String cpf) {
        // comando delete pelo CPF
        String sql = "delete from update_replicacao where cpf = ?;";
        try {
            PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
            ps.setString(1, cpf);
            ps.executeUpdate();
            ConnectionFactory.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Metodo que consulta no BD servidor, na tabela insert_replicacao CPFs
    // a serem atualizados no BD cliente. Retorna um vetor do tipo CpfReplicar
    // chamado pelo metodo Replicar.fazerInsertReplicacao
    public ArrayList<CpfReplicar> pesquisarInsertReplicacao() throws SQLException {
        ResultSet res;
        // Consulta no BD servidor CPFs a serem cadastrados/replicados
        String sql = "select * from insert_replicacao";
        PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
        ArrayList<CpfReplicar> vetorCpfInsert = new ArrayList<>();
        res = ps.executeQuery();
        //int  aux=0;
        // percorre retorno da consulta e cria vetor de CPFs para cadastrar/replicar
        while (res.next()) {
            CpfReplicar cpfReplicar = new CpfReplicar();

            cpfReplicar.setCpf(res.getString("cpf"));
            cpfReplicar.setTipoPessoa(res.getString("tipo_pessoa"));
            vetorCpfInsert.add(cpfReplicar);
            //System.out.println(vetorCpfInsert.get(aux).cpf);
            //System.out.println(vetorCpfInsert.get(aux).tipoPessoa);
            // aux++;
        }
        ConnectionFactory.getConexao().close();
        return vetorCpfInsert; // retorna vetor
    }

    // Metodo que consulta no BD servidor, na tabela update_replicacao CPFs
    // a serem atualizados no BD cliente. Retorna um vetor do tipo CpfReplicar
    // chamado pelo metodo Replicar.fazerUpdateReplicacao
    public ArrayList<CpfReplicar> pesquisarUpdateReplicacao() throws SQLException {
        ResultSet res;
        // Consulta no BD servidor CPFs para serem atualizados
        String sql = "select * from update_replicacao";
        PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
        ArrayList<CpfReplicar> vetorCpfUpdate = new ArrayList<>();
        res = ps.executeQuery();
        // percorre retorno da consulta e cria vetor de CPFs a atualizar
        while (res.next()) {
            CpfReplicar cpfReplicar = new CpfReplicar();
            cpfReplicar.setCpf(res.getString("cpf"));
            cpfReplicar.setCpfOld(res.getString("cpf_old"));
            cpfReplicar.setTipoPessoa(res.getString("tipo_pessoa"));

            vetorCpfUpdate.add(cpfReplicar);
            System.out.println(vetorCpfUpdate);
        }

        ConnectionFactory.getConexao().close();
        return vetorCpfUpdate; // retorna vetor
    }
    
    /* Metodo que faz a REPLICAÇÃO de novo Aluno para WEB */
    public void fazerInsertReplicacao(ArrayList<CpfReplicar> vetorCpfInsert) throws SQLException {
        
        // inicio do Loop para cadastrar objeto Aluno na WEB
        for (CpfReplicar i : vetorCpfInsert) {
       
                AlunoDAO alunoDAO = new AlunoDAO();
                System.out.println(i.getCpf());
                cadastrarAlunoNaWeb(alunoDAO.pesquisarAlunoComMatricula(i.getCpf()));       // cadastrar no cliente 
        }
    }
    // Metodo que recebe um vetor do tipo CpfReplicar chamado pelo metodo Replicar
    // Após analise do tipoPessoa(aluno, professor, servidor ...) chama o metodo cadastrar de cada objeto
    // chamado pelo metodo Replicar
 /*   public void fazerInsertReplicacao(ArrayList<CpfReplicar> vetorCpfInsert) throws SQLException {

         for (int i = 0; i < vetorCpfInsert.size(); i++) {

         if (vetorCpfInsert.get(i).getTipoPessoa().equals("aluno")) {
         AlunoDAO alunoDAO = new AlunoDAO();
         System.out.println(vetorCpfInsert.get(i).getCpf());
         cadastrarAlunoCliente(alunoDAO.pesquisarAlunoComMatricula(vetorCpfInsert.get(i).getCpf()));
         }
         if (vetorCpfInsert.get(i).getTipoPessoa().equals("professor")) {

         }
         if (vetorCpfInsert.get(i).getTipoPessoa().equals("professor_temporario")) {

         }
         if (vetorCpfInsert.get(i).getTipoPessoa().equals("terceirizado")) {

         }
         if (vetorCpfInsert.get(i).getTipoPessoa().equals("servidor")) {

         }
         try {  // exemplo try catch
         }catch (SQLException e) {
         System.out.println("SQL Exception:" + e.getMessage()); 
         System.out.println("SQL Estado:" + e.getSQLState());
         System.out.println("SQL Provider:" + e.getErrorCode());
         }
         }
        // inicio do Loop para analise de tipo de pessoa e cadastrar objeto
        for (CpfReplicar i : vetorCpfInsert) {

            // Se aluno cadastrar
            if (i.getTipoPessoa().equals("aluno")) {
                AlunoDAO alunoDAO = new AlunoDAO();
                System.out.println(i.getCpf());
                //cadastrarPessoaBiblioteca(alunoDAO.pesquisarAlunoComMatricula(i.getCpf())); // cadastrar na biblioteca
                //cadastrarAlunoCliente(alunoDAO.pesquisarAlunoComMatricula(i.getCpf()));       // cadastrar no cliente 
                cadastrarAlunoNaWeb(alunoDAO.pesquisarAlunoComMatricula(i.getCpf()));       // cadastrar no cliente 
            }

            // se professor cadastrar
            if (i.getTipoPessoa().equals("professor")) {
                ProfessorDAO professorDAO = new ProfessorDAO();
                System.out.println(i.getCpf());
                //cadastrarPessoaBiblioteca(professorDAO.pesquisarProfessor(i.getCpf())); // cadastrar na biblioteca
                cadastrarProfessorCliente(professorDAO.pesquisarProfessor(i.getCpf()));       // cadastrar no cliente 
            }

            // se professor_temporario cadastrar
            if (i.getTipoPessoa().equals("professor_temporario")) {

            }
            // se terceirizado cadastrar
            if (i.getTipoPessoa().equals("terceirizado")) {

            }
            // se servidor cadastrar
            if (i.getTipoPessoa().equals("servidor")) {

            }
        }

    }*/

    
// Metodo Boolean que verifica se CPF Old existe no BD WEB         
    public boolean existeCpfOld(CpfReplicar cpfReplicar) throws SQLException { // 
        boolean retorno = true;
        int consulta = 0;

        // consulta a existência da tabela pessoa no BD e retorna 1 caso exista 
        String sql = "select 1 from aluno where cpf = '" + cpfReplicar.getCpfOld() + "';";
        PreparedStatement ps = ConnectionFactoryCliente.getConexao().prepareStatement(sql);

        ResultSet res = ps.executeQuery(); // captar o valor retornado pela consulta
        while (res.next()) {
            consulta = res.getInt("?column?");
        }

        if (consulta != 1) {  // se retorno diferente de 1(verdade) retorna false
            retorno = false;
            System.out.println("CPF não existe no destino! " + cpfReplicar.getCpf());
            System.out.println("valor do retorno: " + retorno);
        } //else{
         //System.out.println("CPF update! " + cpfReplicar.getCpf());
         //System.out.println("valor do retorno: "+retorno);
         //}
        ConnectionFactoryCliente.getConexao().close();
        return retorno;
    }
 /*   // Metodo Boolean que verifica se CPF Old existe no BD destino para fazer alteração         
    public boolean existeCpfOld(CpfReplicar cpfReplicar) throws SQLException { // 
        boolean retorno = true;
        int consulta = 0;

        // consulta a existência da tabela pessoa no BD e retorna 1 caso exista 
        String sql = "select 1 from pessoa where cpf = '" + cpfReplicar.getCpfOld() + "' and tipo_pessoa = '" + cpfReplicar.getTipoPessoa() + "';";
        PreparedStatement ps = ConnectionFactoryCliente.getConexao().prepareStatement(sql);

        ResultSet res = ps.executeQuery(); // captar o valor retornado pela consulta
        while (res.next()) {
            consulta = res.getInt("?column?");
        }

        if (consulta != 1) {  // se retorno diferente de 1(verdade) retorna false
            retorno = false;
            System.out.println("CPF não existe destino! " + cpfReplicar.getCpf());
            System.out.println("valor do retorno: " + retorno);
        } //else{
         //System.out.println("CPF update! " + cpfReplicar.getCpf());
         //System.out.println("valor do retorno: "+retorno);
         //}

        ConnectionFactoryCliente.getConexao().close();
        return retorno;
    }*/

    public void atualizarAlunoCliente(Aluno aluno, String cpfAntigo) throws SQLException { // FALTA FAZER

        String sql = "update aluno set cpf=?, nome=?, rg=?, rg_orgao_emissor=?, rg_orgao_emissor_uf=?, rg_data_emissao=?,"
                + "data_nascimento=? , nacionalidade=?, naturalidade=?, naturalidade_uf=?, estado_civil=?, sexo=?, grau_escolaridade=?,"
                + "titulo_eleitor=?, titulo_eleitor_secao=?, titulo_eleitor_zona=?, titulo_eleitor_uf=?, titulo_eleitor_data_emissao=?,"
                + "certificado_militar_numero=?, certificado_militar_tipo=?, certificado_militar_serie=?, certificado_militar_categoria=?,"
                + "certificado_militar_csm=?,certificado_militar_rm=?, grupo_sanguineo=?, fator_rh=?, filiacao_mae=?, filiacao_pai=?,"
                + "email=?, telefone_1=?, telefone_2=?, endereco=?, numero=?, bairro=?,municipio=?, uf=?, cep=? where cpf=?";
        try {
            PreparedStatement ps = ConnectionFactoryCliente.getConexao().prepareStatement(sql);
            ps.setString(1, aluno.getCpf());
            ps.setString(2, aluno.getNome());
            ps.setString(3, aluno.getRg().getRg());
            ps.setString(4, aluno.getRg().getRgOrgaoEmissor());
            ps.setString(5, aluno.getRg().getRgOrgaoEmissorUf());
            ps.setDate(6, new java.sql.Date(aluno.getRg().getRgDataEmissao().getTime()));
            ps.setDate(7, new java.sql.Date(aluno.getDataNascimento().getTime()));
            ps.setString(8, aluno.getNacionalidade());
            ps.setString(9, aluno.getNaturalidade());
            ps.setString(10, aluno.getNaturalidadeUf());
            ps.setString(11, aluno.getEstadoCivil());
            ps.setString(12, aluno.getSexo());
            ps.setString(13, aluno.getGrauEscolaridade());
            ps.setString(14, aluno.getTituloEleitor().getTituloEleitor());
            ps.setString(15, aluno.getTituloEleitor().getTituloEleitorSecao());
            ps.setString(16, aluno.getTituloEleitor().getTituloEleitorZona());
            ps.setString(17, aluno.getTituloEleitor().getTituloEleitorUf());
            ps.setDate(18, new java.sql.Date(aluno.getTituloEleitor().getTituloEleitorDataEmissao().getTime()));
            ps.setString(19, aluno.getCertificadoMilitar().getCertificadoMilitarNumero());
            ps.setString(20, aluno.getCertificadoMilitar().getCertificadoMilitarTipo());
            ps.setString(21, aluno.getCertificadoMilitar().getCertificadoMilitarSerie());
            ps.setString(22, aluno.getCertificadoMilitar().getCertificadoMilitarCategoria());
            ps.setString(23, aluno.getCertificadoMilitar().getCertificadoMilitarCsm());
            ps.setString(24, aluno.getCertificadoMilitar().getCertificadoMilitarRm());
            ps.setString(25, aluno.getGrupoSanguineo());
            ps.setString(26, aluno.getFatorRh());
            ps.setString(27, aluno.getFiliacaoMae());
            ps.setString(28, aluno.getFiliacaoPai());
            ps.setString(29, aluno.getEmail());
            ps.setString(30, aluno.getTelefone1());
            ps.setString(31, aluno.getTelefone2());
            ps.setString(32, aluno.getEndereco().getEndereco());
            ps.setString(33, aluno.getEndereco().getNumero());
            ps.setString(34, aluno.getEndereco().getBairro());
            ps.setString(35, aluno.getEndereco().getMunicipio());
            ps.setString(36, aluno.getEndereco().getUf());
            ps.setString(37, aluno.getEndereco().getCep());
            ps.setString(38, cpfAntigo);
            ps.executeUpdate();
            ConnectionFactoryCliente.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        limparUpdateReplicacao(aluno.getCpf());
    }

    public void atualizarProfessorCliente(Professor professor, String cpfAntigo) throws SQLException { // FALTA FAZER
        FormacaoDAO formacaoDAO = new FormacaoDAO();
        DependenteDAO dependenteDAO = new DependenteDAO();
        String sql = "update professor set cpf=?, nome=?, rg=?, rg_orgao_emissor=?, rg_orgao_emissor_uf=?, rg_data_emissao=?,"
                + "data_nascimento=? , nacionalidade=?, naturalidade=?, naturalidade_uf=?, estado_civil=?, sexo=?, grau_escolaridade=?,"
                + "titulo_eleitor=?, titulo_eleitor_secao=?, titulo_eleitor_zona=?, titulo_eleitor_uf=?, titulo_eleitor_data_emissao=?,"
                + "certificado_militar_numero=?, certificado_militar_tipo=?, certificado_militar_serie=?, certificado_militar_categoria=?,"
                + "certificado_militar_csm=?,certificado_militar_rm=?, grupo_sanguineo=?, fator_rh=?, filiacao_mae=?, filiacao_pai=?,"
                + "email=?, telefone_1=?, telefone_2=?, endereco=?, numero=?, bairro=?,municipio=?, uf=?, cep=?, pis=?, pis_data_inscricao=?,"
                + "carteira_trabalho=?, carteira_trabalho_serie=?, carteira_trabalho_uf=?, carteira_trabalho_data_emissao=?, cnh=?, cnh_categoria=?,"
                + "cnh_data_emissao=?, conjuge=?, conjuge_cpf=? where cpf=?";
        try {
            PreparedStatement ps = ConnectionFactoryCliente.getConexao().prepareStatement(sql);
            ps.setString(1, professor.getCpf());
            ps.setString(2, professor.getNome());
            ps.setString(3, professor.getRg().getRg());
            ps.setString(4, professor.getRg().getRgOrgaoEmissor());
            ps.setString(5, professor.getRg().getRgOrgaoEmissorUf());
            ps.setDate(6, new java.sql.Date(professor.getRg().getRgDataEmissao().getTime()));
            ps.setDate(7, new java.sql.Date(professor.getDataNascimento().getTime()));
            ps.setString(8, professor.getNacionalidade());
            ps.setString(9, professor.getNaturalidade());
            ps.setString(10, professor.getNaturalidadeUf());
            ps.setString(11, professor.getEstadoCivil());
            ps.setString(12, professor.getSexo());
            ps.setString(13, professor.getFormacao());
            ps.setString(14, professor.getTituloEleitor().getTituloEleitor());
            ps.setString(15, professor.getTituloEleitor().getTituloEleitorSecao());
            ps.setString(16, professor.getTituloEleitor().getTituloEleitorZona());
            ps.setString(17, professor.getTituloEleitor().getTituloEleitorUf());
            ps.setDate(18, new java.sql.Date(professor.getTituloEleitor().getTituloEleitorDataEmissao().getTime()));
            ps.setString(19, professor.getCertificadoMilitar().getCertificadoMilitarNumero());
            ps.setString(20, professor.getCertificadoMilitar().getCertificadoMilitarTipo());
            ps.setString(21, professor.getCertificadoMilitar().getCertificadoMilitarSerie());
            ps.setString(22, professor.getCertificadoMilitar().getCertificadoMilitarCategoria());
            ps.setString(23, professor.getCertificadoMilitar().getCertificadoMilitarCsm());
            ps.setString(24, professor.getCertificadoMilitar().getCertificadoMilitarRm());
            ps.setString(25, professor.getGrupoSanguineo());
            ps.setString(26, professor.getFatorRh());
            ps.setString(27, professor.getFiliacaoMae());
            ps.setString(28, professor.getFiliacaoPai());
            ps.setString(29, professor.getEmail());
            ps.setString(30, professor.getTelefone1());
            ps.setString(31, professor.getTelefone2());
            ps.setString(32, professor.getEndereco().getEndereco());
            ps.setString(33, professor.getEndereco().getNumero());
            ps.setString(34, professor.getEndereco().getBairro());
            ps.setString(35, professor.getEndereco().getMunicipio());
            ps.setString(36, professor.getEndereco().getUf());
            ps.setString(37, professor.getEndereco().getCep());
            ps.setString(38, professor.getPis());
            ps.setDate(39, new java.sql.Date(professor.getPisDataInscricao().getTime()));
            ps.setString(40, professor.getCarteiraTrabalho());
            ps.setString(41, professor.getCarteiraTrabalhoSerie());
            ps.setString(42, professor.getCarteiraTrabalhoUf());
            ps.setDate(43, new java.sql.Date(professor.getCarteiraTrabalhoDataEmissao().getTime()));
            ps.setString(44, professor.getCnh());
            ps.setString(45, professor.getCnhCategoria());
            ps.setDate(46, new java.sql.Date(professor.getCnhDataEmissao().getTime()));
            ps.setString(47, professor.getConjuge());
            ps.setString(48, professor.getConjugeCpf());
            ps.setString(49, cpfAntigo);
            ps.executeUpdate();
            ConnectionFactoryCliente.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        for (int i = 0; i < professor.getVetorDisciplina().size(); i++) {
            MetodosBD metodosBD = new MetodosBD();
            String sqlMinistra = "insert into disciplina_professor(id_disciplina,cpf) values(" + professor.getVetorDisciplina().get(i).id + ",'" + professor.getCpf() + "');";
            metodosBD.executarInstrucao(sqlMinistra);
            System.out.println(sqlMinistra);
        }
        dependenteDAO.cadastrarDependentesProfessor(professor);
        cadastrarRelacaoDependentesProfessor(professor);
        formacaoDAO.cadastrarFormacaoProfessor(professor);
        cadastrarRelacaoFormacaoProfessor(professor);
        limparUpdateReplicacao(professor.getCpf());
    }
    
    /* Metodo que REPLICA update de Aluno na WEB*/
public void fazerUpdateReplicacao(ArrayList<CpfReplicar> vetorCpfUpdate) {

        for (int i = 0; i < vetorCpfUpdate.size(); i++) {
            try {
                if (existeCpfOld(vetorCpfUpdate.get(i))) {
                        AlunoDAO alunoDAO = new AlunoDAO();
                        System.out.println(vetorCpfUpdate.get(i).getCpf());
                        atualizarAlunoNaWeb(alunoDAO.pesquisarAlunoComMatricula(vetorCpfUpdate.get(i).getCpf()), vetorCpfUpdate.get(i).getCpfOld());
                } else {
                    gravarExcecoes(vetorCpfUpdate.get(i));
                    limparUpdateReplicacao(vetorCpfUpdate.get(i).getCpf());
                }    
            } catch (SQLException ex) {
                Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
 /*   public void fazerUpdateReplicacao(ArrayList<CpfReplicar> vetorCpfUpdate) {

//for ( CpfReplicar i : vetorCpfUpdate) {
        for (int i = 0; i < vetorCpfUpdate.size(); i++) {
            try {
                if (existeCpfOld(vetorCpfUpdate.get(i))) {
                    if (vetorCpfUpdate.get(i).getTipoPessoa().equals("aluno")) {
                        AlunoDAO alunoDAO = new AlunoDAO();
                        System.out.println(vetorCpfUpdate.get(i).getCpf());
                        atualizarAlunoCliente(alunoDAO.pesquisarAlunoComMatricula(vetorCpfUpdate.get(i).getCpf()), vetorCpfUpdate.get(i).getCpfOld());
                    }
                    if (vetorCpfUpdate.get(i).getTipoPessoa().equals("professor")) {
                        ProfessorDAO professorDAO = new ProfessorDAO();
                        System.out.println(vetorCpfUpdate.get(i).getCpf());
                        atualizarProfessorCliente(professorDAO.pesquisarProfessor(vetorCpfUpdate.get(i).getCpf()), vetorCpfUpdate.get(i).getCpfOld());
                    }

                } else {
                    gravarExcecoes(vetorCpfUpdate.get(i));
                    limparUpdateReplicacao(vetorCpfUpdate.get(i).getCpf());
                }
                
               //  System.out.println("CPF " + i.getCpf());
               //  System.out.println("CPF OLD " + i.getCpfOld());
               //  System.out.println("TIPO PESSOA " + i.getTipoPessoa());
               //  System.out.println("---------------");
                 
            } catch (SQLException ex) {
                Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }*/

    // Testando a conexão utilizando uma consulta ao BD
 /*public boolean testarConexaoServidor() throws SQLException { // testar a conexao
     boolean retorno = true;
     int consulta = 0;

     // consulta a existência da tabela pessoa no BD e retorna 1 caso exista 
     String sql = "SELECT 1 FROM information_schema.tables WHERE table_name = 'pessoa';";
     PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
        
     ResultSet res = ps.executeQuery(); // captar o valor retornado pela consulta
     while(res.next()){
     consulta = res.getInt("?column?");
     }
            
     if( consulta !1 0 ){  // se retorno diferente de 1(verdade) retorna false
     retorno = false; 
     System.out.println("SEM CONEXÃO COM BANCO DE DADOS!");
     System.out.println("valor do retorno: "+retorno);
     }        
     ConnectionFactory.getConexao().close();
     return retorno;
     }*/
    // Metodo para testar a conexão com o BD Servidor e retorna um Boolean 
    public boolean testarConexaoServidor() /*throws SQLException*/ { // testar a conexao
        boolean retorno = true;
        Connection con = null;
        try {
            con = ConnectionFactory.getConexao();
            // Caso exista alguma exceção na conexão o retorno receberá false
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
            System.out.println("SEM CONEXÃO COM BANCO DE DADOS!");
        } finally {
            try {
                con.close(); // a conexão é finalizada aqui independente das exceções
            } catch (SQLException ex) {
                Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return retorno;
    }

    // Metodo para testar a conexão com o BD Cliente e retorna um Boolean 
    public boolean testarConexaoCliente() { // testar a conexao
        boolean retorno = true;
        Connection con = null;
        try {
            //con = ConnectionFactoryOracle.getConexao();  // testar conexao BD Oracle
            con = ConnectionFactoryMysql.getConexao();   // testar conexao BD postgresql
            // Caso exista alguma exceção na conexão o retorno receberá false
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
            System.out.println("SEM CONEXÃO COM BANCO DE DADOS!");
        } finally {
            try {
                con.close(); // a conexão é finalizada aqui independente das exceções
            } catch (SQLException ex) {
                Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return retorno;
    }
// Metodo para testar a conexao co BD Oracle

    public boolean testarConexaoOracle() { // testar a conexao
        boolean retorno = true;
        Connection con = null;
        try {
            con = ConnectionFactoryOracle.getConexao();  // testar conexao BD Oracle
            //con = ConnectionFactoryCliente.getConexao();   // testar conexao BD postgresql
            // Caso exista alguma exceção na conexão o retorno receberá false
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
            System.out.println("SEM CONEXÃO COM BANCO DE DADOS!");
        } finally {
            try {
                con.close(); // a conexão é finalizada aqui independente das exceções
            } catch (SQLException ex) {
                Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return retorno;
    }

    // Este metodo inicia todo processo de replicação, é chamado no menu princiapl
    // Ele só chama o metodo fazer insert replicação após testar e validar as conexões com os BD
    public void replicar() throws SQLException {

        //if(testarConexaoServidor()&& testarConexaoCliente() && testarConexaoOracle())     
        if (testarConexaoServidor() && testarConexaoCliente()) {
            System.out.println("OK CONEXAO COM BANCO DE DADOS OK.");
            System.out.println("valor do retorno Servidor: " + testarConexaoServidor());
            System.out.println("valor do retorno Cliente: " + testarConexaoCliente());
            //System.out.println("valor do retorno Oracle: " + testarConexaoOracle());
            buscarAlunosDaWeb(pesquisarAlunosComPendencias());
            fazerInsertReplicacao(pesquisarInsertReplicacao());
            fazerUpdateReplicacao(pesquisarUpdateReplicacao());
            
        }
    }

}
