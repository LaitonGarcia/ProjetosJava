/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package provapratica_4bim;

/**
 *
 * @author GARCIA
 */
public class Data {
    private int dia;
    private int mes;
    private int ano;

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        if(validarDia(dia))
            this.dia = dia;
        else
            System.out.println("Dia Inválido");
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        if(validarMes(mes))
            this.mes = mes;
        else
            System.out.println("Mês Inválido!");
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        if(validarAno(ano))
            this.ano = ano;
        else
            System.out.println("Ana Inválido!");
    }
    public boolean validarDia(int dia){
        return dia > 0 && dia <= 23;
    }
    public boolean validarMes(int mes){
        return mes > 0 && mes <= 12;
    }
    public boolean validarAno(int ano){
        return ano > 2000;
    }
    public String mostrarData(){
        return dia+"/"+mes+"/"+ano;
    }
}// fim classe Data
