/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author GARCIA
 */
public class ConnectionFactoryOracle {
    public static  Connection getConexao() throws SQLException {
        
        //nome do usuario do banco
        String usuario = "system";
        
        //senha do usuario do banco
        //String senha = "pgadmim";
        //String senha = "Sobral10*";
        //String senha = "313231";
        //String senha = "administrator";
        String senha = "12345";
        
        
        //ip do banco. para banco no mesmo computador utilize localhost
        String ip = "10.0.0.21"; //João
        //String ip = "192.86.221.196"; //Rubens
        //String ip = "192.86.221.10"; //Patricia
        //String ip = "localhost";
        
        //nome do banco de dados. padrao do postgre eh postgres
        //String bd = "cad_uespi";
        //String bd = "cad_uespi_backup";
        //String bd = "biblioteca";
        String sid = "XE";// ou EX maiuculo
        
        //porta de conexao com o banco de dados. Padrao do postgre eh 5432
        //int porta = 5432;
        int porta = 1521;
        
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            return DriverManager.getConnection("jdbc:oracle:thin:@" + ip + ":" + porta + ":" + sid, usuario, senha);
        } catch (ClassNotFoundException e) {
            throw new SQLException(e.getMessage());
        }
        
    }
}
