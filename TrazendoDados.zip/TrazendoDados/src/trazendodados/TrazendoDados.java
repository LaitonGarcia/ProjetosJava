/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package trazendodados;

import java.sql.PreparedStatement; // 2º Fazer as Importações
import java.sql.ResultSet; // 2º
import java.sql.SQLException; // 2º

/**
 *
 * @author GARCIA
 */
public class TrazendoDados {

    /**
     *  ESCREVA O CODIGO NESTA ORDEM, SIGA O PASSO A PASSO 1º, 2º E TESTE.
     *  O 3º PASSO CRIAR A CLASSE TelaPessoa PARA SETAR OS DADOS IMPORTADOS E TESTAR.
     *  4º PASSO IMPLEMENTAR CHAMADA PARA ENVIAR OS DADOS PARA TELA.
     */
    public static void main(String[] args) throws SQLException {
        TelaPessoa tela = null; // 4º Instancia da classe TelaPessoa, vamos torná-la visível
        ResultSet res;   //  1º
        String sql = "select * from pessoa where cod_pessoa = 2";  // 1º
        PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql); // 1º
       
        res = ps.executeQuery(); // 1º
       
            while (res.next()) {  // 1º
     
            int codigo_pessoa = res.getInt("cod_pessoa"); // 1º
            String nome =  res.getString("nome");   //   1º
            String cargo = res.getString("cargo");   //   1º
            String telefone =  res.getString("telefone");  //   1º
            
            System.out.println("codigo da pessoa: " + codigo_pessoa); // 2º Mostrar no Console
            System.out.println("codigo da pessoa: " + nome);  //   2º
            System.out.println("codigo da pessoa: " + cargo);   //  2º
            System.out.println("codigo da pessoa: " + telefone);  //  2º
            
            if (tela == null){  // 4º
                tela = new TelaPessoa(); // Criando o objeto tela do tipo TelaPessoa
                tela.setVisible(true);  // Tornando a tela visível ao usuário
                tela.setandoDadosNaTela(codigo_pessoa, nome, cargo, telefone); // Chamando metodo que preenche a tela
            }else {  // 4º
                tela.setVisible(true);
                tela.setState(TelaPessoa.NORMAL);
                tela.setandoDadosNaTela(codigo_pessoa, nome, cargo, telefone);
                }
           
            }// fim do while tratando dados ResultSet
        
         ConnectionFactory.getConexao().close();// 1º       
    } // fim do metodo main     
}// fim da classe TrazendoDados
    

