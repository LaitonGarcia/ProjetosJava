/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conta;

import java.util.ArrayList;

/**
 *
 * @author GARCIA
 */
public class Conta {
    private int CodigoConta;
    private double saldo;
   // private Pessoa cliente = new Pessoa();
    private ArrayList<Pessoa> clientes = new ArrayList<Pessoa>();

    public int getCodigoConta() {
        return CodigoConta;
    }

    public void setCodigoConta(int CodigoConta) {
        this.CodigoConta = CodigoConta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
/*
    public Pessoa getCliente() {
        return clientes;
    }

    public void setCliente(Pessoa clientes) {
        this.clientes = clientes;
    }
    */
    public void ApresentarContaCorrente(){
        System.out.println("Numero da Conta: "+CodigoConta);
        System.out.println("Saldo: "+ saldo);
       // clientes.ApresentarPessoa();
        for(Pessoa p: clientes)
            p.ApresentarPessoa();
    }

    public ArrayList<Pessoa> getClientes(){
        return clientes;
    }

    public void setClientes(ArrayList<Pessoa> clientes) {
        this.clientes = clientes;
    }
    public Pessoa pesquisarCliente(String nomePessoa){
        for(Pessoa acheiPessoa: clientes){
            if(acheiPessoa.getNome().equalsIgnoreCase(nomePessoa)){
                return acheiPessoa;
            }
        }    
        return null;
    }// fim metodo pesquisarCliente
    
}// fim da classe Conta
