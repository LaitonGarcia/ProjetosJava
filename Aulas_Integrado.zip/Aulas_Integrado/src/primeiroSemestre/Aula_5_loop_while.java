/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package primeiroSemestre;

import java.util.Scanner;

/**
 *
 * @author GARCIA
 */
public class Aula_5_loop_while {
   
    public static void main(String[] args) {
   /*  
        int idade = 199;
        while (idade > 18) {
            System.out.println(idade);
            idade = idade - 1;
        }
    */
   /*     
        Scanner ler = new Scanner(System.in);
        int olha_o_doido = 0;
        
        while(olha_o_doido <1 || olha_o_doido >7){
            System.out.print("Digite um número: ");
            olha_o_doido = ler.nextInt();
            System.out.printf("Digitei o %d \n", olha_o_doido);
        }
        
        
        
        System.out.println("\n\n\n\n\n");
        
        
        
        System.out.println("\nEITA BICHO DOIDO!");
  */     
    /*    
        int i = 0;
        while (i < 10) {
            System.out.println(i);
            i = i + 1; // e se usarmos o operador de Incremento ++
        }
    */  
    /*    
        for (int i = 0; i < 10; i = i + 1) {
            System.out.println("olá! ");                                 // + (i+1) +"º" int x = 1;
        }  // ou com while
    */
   /*     
        int i = 0;
        while (i < 10) {      // Tentação while(int i < 10){
            System.out.println("olá!");
            i = i + 1;
        }
    */
    /*
       int x = 0;
       int y = 1000;
       for (int i = x; i < y; i++) {
            if (i % 19 == 0) {
                System.out.println("Achei um número divisível por 19 entre x e y: ");
                break;
            }
        }
   */
   /*
       for (int i = 0; i < 20; i++) {
            if (i > 10 && i < 15) {
                continue;
            }
            System.out.println(i);
       }
   */
        
 /*   // ESCOPO DE VARIáVEL
    if (1 > 0) {
        int i = 5;
    }
      else {
            int i = 10;
    }
    System.out.println(i);   
 */ 
 /*
    for (int i = 0; i < 10; i++) {
        System.out.println("olá!");
    }
    System.out.println(i); 
 */    
  /*
        int a=5;
        int b = a;
        System.out.println("a = "+a+" b = "+b);
        //a =6;
        //System.out.println("a = "+a+" b = "+b);
  */
       
/*       // COMPARANDO Strings 
    String a , b;
    a= "ABC";
    b = "abc";
    System.out.println(a.equals(b));
    System.out.print(b.equalsIgnoreCase(a));
*/
 /*       int product=1;
        while (product <= 100){
            product = 3 * product;
            System.out.println("valor "+product);
        }
  */
       String x="a";
       String a="e";
       int y = 0;
       do{ 
           System.out.println("valor "+ x +" "+ y);
           y++;
       }while(!x.equalsIgnoreCase(a));
        
    } // fim do main
}// fim da classe Aula_5_loop_while
