
package replicar;

import dao.AlunoDAO;

import dao.conexao.ConnectionFactory;
import dao.conexao.ConnectionFactoryBackup;
import dao.conexao.ConnectionFactoryMysql;
import entidades.Aluno;
import entidades.CpfReplicar;
import entidades.util.Endereco;
import entidades.util.Rg;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ReplicarWeb {


    public void updateAuxiliarAlunosWeb() throws SQLException {
        apagarDadosDaAuxiliarWeb();
    }

    public void apagarDadosDaAuxiliarWeb() throws SQLException {
        String sql = "truncate auxiliar_alteracao_web;";
        PreparedStatement ps = ConnectionFactoryMysql.getConexao().prepareStatement(sql);
        ps.executeUpdate();
        ConnectionFactoryMysql.getConexao().close();
    }
    /* Consultar na WEB registros na tabela auxiliar_alteracao_web e Trazer vetor de Alunos que solicitaram alteraçao */
    public ArrayList<Aluno> pesquisarAlunosComPendencias() throws SQLException { // FALTA TESTAR
              System.out.println(" buscarAlunosDaWeb Aluno nome:");
        System.out.println("buscarAlunosDaWeb Aluno tipo pessoa:");
        ResultSet res;
        String sql = "select * from auxiliar_alteracao_web";
        PreparedStatement ps = ConnectionFactoryMysql.getConexao().prepareStatement(sql);
        ArrayList<Aluno> vetorAluno = new ArrayList<>();
        res = ps.executeQuery();
        try {
            while (res.next()) {
                Aluno aluno = new Aluno();
                Rg rg = new Rg();
                rg.setRg(res.getString("rg"));
                rg.setRgOrgaoEmissor(res.getString("rg_orgao_emissor"));
                rg.setRgOrgaoEmissorUf(res.getString("rg_orgao_emissor_uf"));
                aluno.setRg(rg);
                aluno.setCpf(res.getString("cpf"));
                aluno.setNome(res.getString("nome"));
                aluno.setDataNascimento(res.getDate("data_nascimento"));
                aluno.setEstadoCivil(res.getString("estado_civil"));
                aluno.setSexo(res.getString("sexo"));
                aluno.setFiliacaoMae(res.getString("filiacao_mae"));
                aluno.setFiliacaoPai(res.getString("filiacao_pai"));
                aluno.setEmail(res.getString("email"));
                aluno.setTelefone1(res.getString("telefone_1"));
                aluno.setTelefone2(res.getString("telefone_2"));
                Endereco endereco = new Endereco();
                endereco.setEndereco(res.getString("endereco"));
                endereco.setNumero(res.getString("numero"));
                endereco.setBairro(res.getString("bairro"));
                endereco.setMunicipio(res.getString("municipio"));
                endereco.setUf(res.getString("uf"));
                endereco.setCep(res.getString("cep"));
                aluno.setEndereco(endereco);
                aluno.setTipoPessoa(res.getString("tipo_pessoa"));
                vetorAluno.add(aluno);
                System.out.println("Pesquisando alunos com pendencias: "+aluno.getNome());
            }
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        ConnectionFactoryMysql.getConexao().close();
        return vetorAluno;
    }

    /* Registrar no BD LOCAL na tabela auxiliar_web_local a solicitação de Alunos via WEB para alteração de Dados manual */
    public void cadastrarAlunoAuxiliarWebLocal(Aluno aluno) { 
        String sql = "insert into auxiliar_web_local (cpf,nome,senha,rg,rg_orgao_emissor,rg_orgao_emissor_uf,"
                + "data_nascimento,estado_civil,sexo, filiacao_mae,filiacao_pai,"
                + "email, telefone_1, telefone_2, endereco, numero, bairro,municipio, uf, cep,tipo_pessoa)"
                + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
            ps.setString(1, aluno.getCpf());
            ps.setString(2, aluno.getNome());
            ps.setString(3, aluno.getSenha());
            ps.setString(4, aluno.getRg().getRg());
            ps.setString(5, aluno.getRg().getRgOrgaoEmissor());
            ps.setString(6, aluno.getRg().getRgOrgaoEmissorUf());
            ps.setDate(7,new java.sql.Date( aluno.getDataNascimento().getTime()));
            ps.setString(8, aluno.getEstadoCivil());
            ps.setString(9, aluno.getSexo());
            ps.setString(10, aluno.getFiliacaoMae());
            ps.setString(11, aluno.getFiliacaoPai());
            ps.setString(12, aluno.getEmail());
            ps.setString(13, aluno.getTelefone1());
            ps.setString(14, aluno.getTelefone2());
            ps.setString(15, aluno.getEndereco().getEndereco());
            ps.setString(16, aluno.getEndereco().getNumero());
            ps.setString(17, aluno.getEndereco().getBairro());
            ps.setString(18, aluno.getEndereco().getMunicipio());
            ps.setString(19, aluno.getEndereco().getUf());
            ps.setString(20, aluno.getEndereco().getCep());
            ps.setString(21, aluno.getTipoPessoa());
            ps.executeUpdate();

            ConnectionFactory.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
            gravarExcecoes(aluno.getCpf(), aluno.getTipoPessoa(), ex.getMessage(), ex.toString());
            System.out.println("SQL Provider:W " + ex.getErrorCode());
        }
    }
    
    /* Metodo recebe Vetor de Alunos da WEB que solicitaram alterações cadastrais e registra na tabela auxiliar_web_local */
    public void buscarAlunosDaWeb(ArrayList<Aluno> alunos) throws SQLException {

        for (Aluno i : alunos) {
                cadastrarAlunoAuxiliarWebLocal(i); // Quando outros tipos forem usados apagar essa linha
         
        }
        updateAuxiliarAlunosWeb();
    }
    
    /* Metodo que Cadastra novo Aluno no BD WEB */
    public void cadastrarAlunoNaWeb(Aluno aluno) throws SQLException {
        String sql = "insert into aluno (cpf, nome, senha, rg, rg_orgao_emissor, rg_orgao_emissor_uf,"
                + "data_nascimento, estado_civil, sexo, filiacao_mae, filiacao_pai, email, telefone_1, "
                + "telefone_2, endereco, numero, bairro, municipio, uf, cep, tipo_pessoa)"
                + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = ConnectionFactoryMysql.getConexao().prepareStatement(sql);
            ps.setString(1, aluno.getCpf());
            ps.setString(2, aluno.getNome());
            ps.setString(3,aluno.getSenha());
            ps.setString(4, aluno.getRg().getRg());
            ps.setString(5, aluno.getRg().getRgOrgaoEmissor());
            ps.setString(6, aluno.getRg().getRgOrgaoEmissorUf());
            ps.setDate(7, new java.sql.Date(aluno.getDataNascimento().getTime()));
            ps.setString(8, aluno.getEstadoCivil());
            ps.setString(9, aluno.getSexo());
            ps.setString(10, aluno.getFiliacaoMae());
            ps.setString(11, aluno.getFiliacaoPai());
            ps.setString(12, aluno.getEmail());
            ps.setString(13, aluno.getTelefone1());
            ps.setString(14, aluno.getTelefone2());
            ps.setString(15, aluno.getEndereco().getEndereco());
            ps.setString(16, aluno.getEndereco().getNumero());
            ps.setString(17, aluno.getEndereco().getBairro());
            ps.setString(18, aluno.getEndereco().getMunicipio());
            ps.setString(19, aluno.getEndereco().getUf());
            ps.setString(20, aluno.getEndereco().getCep());
            ps.setString(21, aluno.getTipoPessoa());
            ps.executeUpdate();
            ConnectionFactoryMysql.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
            gravarExcecoes(aluno.getCpf(), aluno.getTipoPessoa(), ex.getMessage(), ex.toString());
            System.out.println("SQL Provider:W " + ex.getErrorCode());
            // o metodo getSQLState é inicializado com null, então armazenar CPF pra analise Manual
            //if(ex.getSQLState()!= null)System.out.println(" AQUI instrução PARA ARMAZENAR ESTE cpf PARA ANALISE ");
                /*System.out.println("SQL Exception:W " + ex.getMessage()); 
             System.out.println("SQL outro: W " + ex.getLocalizedMessage()+ "outro 1 W "+ ex.toString()+ "outro 2 W "+ ex.getCause()+ "outro 3 W "+ ex.getClass());
             System.out.println("SQL Estado: W " + ex.getSQLState());
             System.out.println("SQL Provider:W " + ex.getErrorCode());
             System.out.println(" FIM do que EU quero ");
             System.out.println("SQL Exception:W " + ex.getMessage());*/

            /*if(ex.getErrorCode()!= 1)System.out.println("Code ALUNO NÂO CADASTRADO E INSERIDO ANALISE MANUAL");
             if(ex.getMessage()!= null)System.out.println("Message ALUNO NÂO CADASTRADO E INSERIDO ANALISE MANUAL");
             System.out.println("SQL Provider:" + ex.getErrorCode());
             System.out.println("ESTE ALUNO NÂO FOI CADASTRADO:" + aluno.getNome());
             System.out.println("SQL Exception:" + ex.getMessage()); 
             System.out.println("SQL Estado:" + ex.getSQLState());
             System.out.println("SQL Provider:" + ex.getErrorCode());
             System.out.println("FIM do que EU quero");*/
        }
        limparInsertReplicacao(aluno.getCpf());
    }
    
    /* Metodo que Atualiza dados de Aluno no BD WEB */
    public void atualizarAlunoNaWeb(Aluno aluno, String cpfAntigo) throws SQLException {

        String sql = "update aluno set cpf=?, nome=?, senha=?, rg=?, rg_orgao_emissor=?, rg_orgao_emissor_uf=?,"
                + "data_nascimento=? , estado_civil=?, sexo=?, filiacao_mae=?, filiacao_pai=?, email=?, "
                + "telefone_1=?, telefone_2=?, endereco=?, numero=?, bairro=?, municipio=?, uf=?, cep=? where cpf=?";
        try {
            PreparedStatement ps = ConnectionFactoryMysql.getConexao().prepareStatement(sql);
            ps.setString(1, aluno.getCpf());
            ps.setString(2, aluno.getNome());
            ps.setString(3,aluno.getSenha());
            ps.setString(4, aluno.getRg().getRg());
            ps.setString(5, aluno.getRg().getRgOrgaoEmissor());
            ps.setString(6, aluno.getRg().getRgOrgaoEmissorUf());
            ps.setDate(7, new java.sql.Date(aluno.getDataNascimento().getTime()));
            ps.setString(8, aluno.getEstadoCivil());
            ps.setString(9, aluno.getSexo());
            ps.setString(10, aluno.getFiliacaoMae());
            ps.setString(11, aluno.getFiliacaoPai());
            ps.setString(12, aluno.getEmail());
            ps.setString(13, aluno.getTelefone1());
            ps.setString(14, aluno.getTelefone2());
            ps.setString(15, aluno.getEndereco().getEndereco());
            ps.setString(16, aluno.getEndereco().getNumero());
            ps.setString(17, aluno.getEndereco().getBairro());
            ps.setString(18, aluno.getEndereco().getMunicipio());
            ps.setString(19, aluno.getEndereco().getUf());
            ps.setString(20, aluno.getEndereco().getCep());
            ps.setString(21, cpfAntigo);
            ps.executeUpdate();
            ConnectionFactoryMysql.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
            gravarExcecoes(aluno.getCpf(), aluno.getTipoPessoa(), ex.getMessage(), ex.toString());
            System.out.println("SQL Provider:W " + ex.getErrorCode());
        }
        limparUpdateReplicacao(aluno.getCpf());
    }    

    // Metodo que registra as exceções com seu motivo, a ser tratado manualmente pelo DBA
    // Invocado no metodo Replicar.cadastrarAlunoCliente em SQLException que envia o CPF,
    // tipoPessoa e mensagem de exceçao e registrados na tabela excecoes_replicacao
    public void gravarExcecoes(String cpf, String tipoPessoa, String excecao, String bancoDeDados) {
        // registrando as exceções
        String sql = "insert into excecoes_replicacao (cpf,tipo_pessoa, mensagem_excecao,banco_de_dados )"
                + "values(?,?,?,?)";
        try {
            PreparedStatement ps = ConnectionFactoryBackup.getConexao().prepareStatement(sql);
            ps.setString(1, cpf);
            ps.setString(2, tipoPessoa);
            ps.setString(3, excecao);
            ps.setString(4, bancoDeDados);
            ps.executeUpdate();
            ConnectionFactoryBackup.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
        }
        /*     // testando importação de dados
         System.out.println("CPF: " + cpf);
         System.out.println("Tipo de Pessoa: " + tipoPessoa);
         System.out.println("Mensagem exceção: " + excecao);
        /*     // testando importação de dados
         System.out.println("CPF: " + cpf);
         System.out.println("Tipo de Pessoa: " + tipoPessoa);
         System.out.println("Mensagem exceção: " + excecao);
         */
    }

    // Metodo que registra exceções no update, Invocado pelo metodo fazerUpdateReplicacao
    // quando CPF_OLD não existe no BD destino a alteração não pode ser registrada, então
    // registra-se na tabela excecoes_replicacao a ser tratado manualmente pelo DBA
    public void gravarExcecoes(CpfReplicar cpfUpdateExcecao) {
        // registrando as exceções, neste caso dos CPF_OLD não encontrado no BD destino
        String sql = "insert into excecoes_replicacao (cpf, cpf_old, tipo_pessoa, mensagem_excecao )"
                + "values(?,?,?,?)";
        try {
            PreparedStatement ps = ConnectionFactoryBackup.getConexao().prepareStatement(sql);
            ps.setString(1, cpfUpdateExcecao.getCpf());
            ps.setString(2, cpfUpdateExcecao.getCpfOld());
            ps.setString(3, cpfUpdateExcecao.getTipoPessoa());
            ps.setString(4, "CPF OLD não existe no BD destino para ser alterado!");
            ps.executeUpdate();
            ConnectionFactoryBackup.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
        }
        /*     // testando importação de dados
         System.out.println("CPFexcecao " + cpfUpdateExcecao.getCpf());
         System.out.println("CPF OLDexcecao " + cpfUpdateExcecao.getCpfOld());
         System.out.println("TIPO PESSOAexcecao " + cpfUpdateExcecao.getTipoPessoa());
         System.out.println("CPF OLD não existe no BD destino para ser alterado!");
        /*     // testando importação de dados
         System.out.println("CPFexcecao " + cpfUpdateExcecao.getCpf());
         System.out.println("CPF OLDexcecao " + cpfUpdateExcecao.getCpfOld());
         System.out.println("TIPO PESSOAexcecao " + cpfUpdateExcecao.getTipoPessoa());
         System.out.println("CPF OLD não existe no BD destino para ser alterado!");
         */
    }

    // Metodo que limpa a tabela insert_replicacao no BD servidor para evitar
    // redundâncias de dados que criariam exceções na replicação de dados, restrição 
    // de unicidade de chave primaria(PK) do BD
    // chamado pelo metodo Replicar.cadastrarAlunoCliente com um CPF após tratamento de exceções
    public void limparInsertReplicacao(String cpf) {
        // comando delete pelo CPF
        String sql = "delete from insert_replicacao where cpf = ?;";
        try {
            PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
            ps.setString(1, cpf);
            ps.executeUpdate();
            ConnectionFactory.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void limparUpdateReplicacao(String cpf) {
        // comando delete pelo CPF
        String sql = "delete from update_replicacao where cpf = ?;";
        try {
            PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
            ps.setString(1, cpf);
            ps.executeUpdate();
            ConnectionFactory.getConexao().close();
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Metodo que consulta no BD servidor, na tabela insert_replicacao CPFs
    // a serem atualizados no BD cliente. Retorna um vetor do tipo CpfReplicar
    // chamado pelo metodo Replicar.fazerInsertReplicacao
    public ArrayList<CpfReplicar> pesquisarInsertReplicacao() throws SQLException {
        ResultSet res;
        // Consulta no BD servidor CPFs a serem cadastrados/replicados
        String sql = "select * from insert_replicacao";
        PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
        ArrayList<CpfReplicar> vetorCpfInsert = new ArrayList<>();
        res = ps.executeQuery();
        //int  aux=0;
        // percorre retorno da consulta e cria vetor de CPFs para cadastrar/replicar
        while (res.next()) {
            CpfReplicar cpfReplicar = new CpfReplicar();

            cpfReplicar.setCpf(res.getString("cpf"));
            cpfReplicar.setTipoPessoa(res.getString("tipo_pessoa"));
            vetorCpfInsert.add(cpfReplicar);
            //System.out.println(vetorCpfInsert.get(aux).cpf);
            //System.out.println(vetorCpfInsert.get(aux).tipoPessoa);
            // aux++;
        }
        ConnectionFactory.getConexao().close();
        return vetorCpfInsert; // retorna vetor
    }

    // Metodo que consulta no BD servidor, na tabela update_replicacao CPFs
    // a serem atualizados no BD cliente. Retorna um vetor do tipo CpfReplicar
    // chamado pelo metodo Replicar.fazerUpdateReplicacao
    public ArrayList<CpfReplicar> pesquisarUpdateReplicacao() throws SQLException {
        ResultSet res;
        // Consulta no BD servidor CPFs para serem atualizados
        String sql = "select * from update_replicacao";
        PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
        ArrayList<CpfReplicar> vetorCpfUpdate = new ArrayList<>();
        res = ps.executeQuery();
        // percorre retorno da consulta e cria vetor de CPFs a atualizar
        while (res.next()) {
            CpfReplicar cpfReplicar = new CpfReplicar();
            cpfReplicar.setCpf(res.getString("cpf"));
            cpfReplicar.setCpfOld(res.getString("cpf_old"));
            cpfReplicar.setTipoPessoa(res.getString("tipo_pessoa"));

            vetorCpfUpdate.add(cpfReplicar);
            System.out.println(vetorCpfUpdate);
        }

        ConnectionFactory.getConexao().close();
        return vetorCpfUpdate; // retorna vetor
    }
    
    /* Metodo que faz a REPLICAÇÃO de novo Aluno para WEB */
    public void fazerInsertReplicacao(ArrayList<CpfReplicar> vetorCpfInsert) throws SQLException {
        
        // inicio do Loop para cadastrar objeto Aluno na WEB
        for (CpfReplicar i : vetorCpfInsert) {
       
                AlunoDAO alunoDAO = new AlunoDAO();
                System.out.println(i.getCpf());
                cadastrarAlunoNaWeb(alunoDAO.pesquisarAlunoComMatricula(i.getCpf()));       // cadastrar no cliente 
        }
    }
    
    
// Metodo Boolean que verifica se CPF Old existe no BD WEB         
    public boolean existeCpfOld(CpfReplicar cpfReplicar) throws SQLException { // 
        boolean retorno = true;
        int consulta = 0;

        // consulta a existência na tabela pessoa no BD e retorna 1 caso exista 
        String sql = "select 1 from aluno where cpf = '" + cpfReplicar.getCpfOld() + "';";
        PreparedStatement ps = ConnectionFactoryMysql.getConexao().prepareStatement(sql);

        ResultSet res = ps.executeQuery(); // captar o valor retornado pela consulta
        while (res.next()) {
            consulta = res.getInt("1");
        }

        if (consulta != 1) {  // se retorno diferente de 1(verdade) retorna false
            retorno = false;
            System.out.println("CPF não existe no destino! " + cpfReplicar.getCpf());
            System.out.println("valor do retorno: " + retorno);
        } //else{
         //System.out.println("CPF update! " + cpfReplicar.getCpf());
         //System.out.println("valor do retorno: "+retorno);
         //}
        ConnectionFactoryMysql.getConexao().close();
        return retorno;
    }
 
    
    /* Metodo que REPLICA update de Aluno na WEB*/
public void fazerUpdateReplicacao(ArrayList<CpfReplicar> vetorCpfUpdate) {

        for (int i = 0; i < vetorCpfUpdate.size(); i++) {
            try {
                if (existeCpfOld(vetorCpfUpdate.get(i))) {
                        AlunoDAO alunoDAO = new AlunoDAO();
                        System.out.println(vetorCpfUpdate.get(i).getCpf());
                        atualizarAlunoNaWeb(alunoDAO.pesquisarAlunoComMatricula(vetorCpfUpdate.get(i).getCpf()), vetorCpfUpdate.get(i).getCpfOld());
                } else {
                    gravarExcecoes(vetorCpfUpdate.get(i));
                    limparUpdateReplicacao(vetorCpfUpdate.get(i).getCpf());
                }    
            } catch (SQLException ex) {
                Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
 
    // Testando a conexão utilizando uma consulta ao BD
 /*public boolean testarConexaoServidor() throws SQLException { // testar a conexao
     boolean retorno = true;
     int consulta = 0;

     // consulta a existência da tabela pessoa no BD e retorna 1 caso exista 
     String sql = "SELECT 1 FROM information_schema.tables WHERE table_name = 'pessoa';";
     PreparedStatement ps = ConnectionFactory.getConexao().prepareStatement(sql);
        
     ResultSet res = ps.executeQuery(); // captar o valor retornado pela consulta
     while(res.next()){
     consulta = res.getInt("?column?");
     }
            
     if( consulta !1 0 ){  // se retorno diferente de 1(verdade) retorna false
     retorno = false; 
     System.out.println("SEM CONEXÃO COM BANCO DE DADOS!");
     System.out.println("valor do retorno: "+retorno);
     }        
     ConnectionFactory.getConexao().close();
     return retorno;
     }*/
    // Metodo para testar a conexão com o BD Servidor e retorna um Boolean 
    public boolean testarConexaoServidor() /*throws SQLException*/ { // testar a conexao
        boolean retorno = true;
        Connection con = null;
        try {
            con = ConnectionFactory.getConexao();
            // Caso exista alguma exceção na conexão o retorno receberá false
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
            System.out.println("SEM CONEXÃO COM BANCO DE DADOS!");
        } finally {
            try {
                con.close(); // a conexão é finalizada aqui independente das exceções
            } catch (SQLException ex) {
                Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return retorno;
    }

    // Metodo para testar a conexão com o BD Cliente e retorna um Boolean 
    public boolean testarConexaoMysql() { // testar a conexao
        boolean retorno = true;
        Connection con = null;
        try {
            
            con = ConnectionFactoryMysql.getConexao();   // testar conexao BD Mysql
            // Caso exista alguma exceção na conexão o retorno receberá false
        } catch (SQLException ex) {
            Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            retorno = false;
            System.out.println("SEM CONEXÃO COM BANCO DE DADOS!");
        } finally {
            try {
                con.close(); // a conexão é finalizada aqui independente das exceções
            } catch (SQLException ex) {
                Logger.getLogger(Replicar.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return retorno;
    }


    // Este metodo inicia todo processo de replicação, é chamado no menu princiapl
    // Ele só chama o metodo fazer insert replicação após testar e validar as conexões com os BD
    public void replicar() throws SQLException {
   
        if (testarConexaoServidor() && testarConexaoMysql()) {
            
            System.out.println("OK CONEXAO COM BANCO DE DADOS OK.");
            System.out.println("valor do retorno Servidor: " + testarConexaoServidor());
            System.out.println("valor do retorno Cliente: " + testarConexaoMysql());
   
            buscarAlunosDaWeb(pesquisarAlunosComPendencias());
            fazerInsertReplicacao(pesquisarInsertReplicacao());
            fazerUpdateReplicacao(pesquisarUpdateReplicacao());   
        }
    }

}
