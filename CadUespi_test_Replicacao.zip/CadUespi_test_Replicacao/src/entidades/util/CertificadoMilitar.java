/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entidades.util;

/**
 *
 * @author Rubens
 */
public class CertificadoMilitar {
    
    private String certificadoMilitarNumero;

    public String getCertificadoMilitarNumero() {
        return certificadoMilitarNumero;
    }

    public void setCertificadoMilitarNumero(String certificadoMilitarNumero) {
        this.certificadoMilitarNumero = certificadoMilitarNumero;
    }
    private String certificadoMilitarTipo;
    private String certificadoMilitarSerie;
    private String certificadoMilitarCategoria;
    private String certificadoMilitarCsm;
    private String certificadoMilitarRm;

    public String getCertificadoMilitarTipo() {
        return certificadoMilitarTipo;
    }

    public void setCertificadoMilitarTipo(String certificadoMilitarTipo) {
        this.certificadoMilitarTipo = certificadoMilitarTipo;
    }

    public String getCertificadoMilitarSerie() {
        return certificadoMilitarSerie;
    }

    public void setCertificadoMilitarSerie(String certificadoMilitarSerie) {
        this.certificadoMilitarSerie = certificadoMilitarSerie;
    }

    public String getCertificadoMilitarCategoria() {
        return certificadoMilitarCategoria;
    }

    public void setCertificadoMilitarCategoria(String certificadoMilitarCategoria) {
        this.certificadoMilitarCategoria = certificadoMilitarCategoria;
    }

    public String getCertificadoMilitarCsm() {
        return certificadoMilitarCsm;
    }

    public void setCertificadoMilitarCsm(String certificadoMilitarCsm) {
        this.certificadoMilitarCsm = certificadoMilitarCsm;
    }

    public String getCertificadoMilitarRm() {
        return certificadoMilitarRm;
    }

    public void setCertificadoMilitarRm(String certificadoMilitarRm) {
        this.certificadoMilitarRm = certificadoMilitarRm;
    }
}
