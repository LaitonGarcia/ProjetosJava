

package aprendendojava;

import java.util.Scanner;


public class PerguntasMostrar {
    Scanner leitura = new Scanner(System.in);
    Calculos calculo = new Calculos();
    
    public int perguntaNum1 (){  
        System.out.println("Entre com o primeiro número: ");
        int num = leitura.nextInt();
        
        return num;
    }
    
    public int perguntaNum2(){
        System.out.println("Entre com o segundo número: ");
        int num = leitura.nextInt();
        
        return num;
    }
    
    public String perguntaNome(){
        System.out.println("Qual o nome? ");
        leitura.nextLine(); // limpando buffer
        String nome = leitura.nextLine();
        
        return nome;
    }
    
    public String continuarSair(){
        System.out.println("\n\tDigite qualquer NUMERO para CONTINUAR!");
        System.out.println("\n\t  Digite qualquer LETRA para SAIR!");
        String sair = leitura.next();
        return sair;
    }
    
    public void mostrarResultado(int num1, int num2){
        System.out.printf("O resultado da soma é %d\n", calculo.soma(num1, num2));
    }
    
    public void mostrarQuadrado(int num){
        System.out.println("O quadrado de "+ num + " é " + calculo.quadrado(num));
    }
    
    public void mostrarCubo(int num){
        System.out.println("O cubo de "+ num + " é " + calculo.cubo(num));
    }
    
    public void comparacao(int num1, int num2){
     
        if(calculo.igualdade(num1, num2))
            System.out.println(num1 + " é igual a " + num2);
        if(calculo.diferente(num1, num2)) 
            System.out.println(num1 + " é diferente de " + num2);
        if(calculo.menorQue(num1, num2))  
            System.out.println(num1 + " é menor que " + num2);
        if(calculo.maiorQue(num1, num2))  
            System.out.println(num1 + " é maior que " + num2);
        if(calculo.menorIgaul(num1, num2)) 
            System.out.println(num1 + " é menor ou igual a " + num2);
        if(calculo.maiorIgual(num1, num2)) 
            System.out.println(num1 + " é maior ou igual a " + num2);
    }
    
    public void subMenu(){
       
            
           int numero1 = perguntaNum1();
        
           int numero2 = perguntaNum2();
        
           String nome = perguntaNome();
       
           System.out.println("Meu nome é " + nome);
        
           comparacao(numero1, numero2);
        
           mostrarQuadrado(numero1);
        
           mostrarCubo(numero2);
        
    }
      
}