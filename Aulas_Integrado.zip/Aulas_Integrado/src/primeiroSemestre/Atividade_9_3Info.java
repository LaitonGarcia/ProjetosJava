/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package primeiroSemestre;

/**
 *
 * @author GARCIA
 */
public class Atividade_9_3Info {
    int x =7;
    public static void main( String[ ] args ){
        
      /*
        // Resposta questão 2:
        //O que seguinte programa imprime?		
                int y;
		int x = 1;
		int total = 0;
		while( x <= 3 ){
			y = x * x;
			System.out.println( y );
                        System.out.printf("x=%d",x);
			total += y;
			++x;
                } // fim do while
                System.out.printf( "Total vale %d\n", total );
    */
    /*  
       // A)
       // int c=1, produto=1;
        while( c <= 5 ) {
	produto *= c;
        //System.out.printf( "produto %d\n", produto );
	++c;
        //System.out.printf( "C %d\n", c );
        }// fim do while
     */
     /* 
        // B)
        // int genero = 1;
        if( genero == 1 )
            System.out.println("Mulher");
        else;
            System.out.println("Homem");
     */ 
     /* 
        // C)
        // int z = 0, soma = 0;
        while( z >= 0 )
	soma += z;
    */ 
     /*  
        // D)
        // int idade = 0;
       if( idade => 65 );
	System.out.println("Sua idade é igual ou maior que 65.");
      else
	System.out.println("Você tem menos de 65 anos");
    */
   /*  
      // E)
      int x = 1, total;
      while( x <= 10 ){
	total += x;
       // System.out.printf( "total %d\n", total);
	++x;
       // System.out.printf( "x %d\n", x );
      
      }// fim do while
   */
   /* 
        // F)
        //int y = 0,total = 0;
        while( y <= 100 )
	total += y;
 	++y;
   */
   /*   
        // G)
        while( y > 0 ) {
	System.out.println( y );
	++y
   */     
     }// fim do main

}
