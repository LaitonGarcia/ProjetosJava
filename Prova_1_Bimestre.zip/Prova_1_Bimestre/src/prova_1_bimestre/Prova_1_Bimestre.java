/*
 */

package prova_1_bimestre;

import java.util.Scanner;

public class Prova_1_Bimestre {
    
     // Sugestões de Respostas Prova 1º Bimestre
    
    public static void main(String[] args) {
       
         // Questão 1 (2 pontos)
           // O teorema de Pitágoras é uma relação matemática entre os três lados de qualquer
           // triângulo retângulo. Por definição, a hipotenusa é o lado oposto ao ângulo reto, 
           // e os catetos são os dois lados que o formam. Faça um programa que receba o valor 
           // dos catetos do triângulo digitados pelo usuário no console do NetBeans, calcule 
           // e mostre o valor da hipotenusa. Pode-se equacionar o cálculo da hipotenusa como 
           // sendo: c² = a² + b², onde c representa o comprimento da hipotenusa, e a e b 
           //representam os comprimentos dos outros dois lados.
  /*
            double catetoA;
            double catetoB;
            double hipotenusaC;
            Scanner entradaDados = new Scanner(System.in);

            System.out.print("Digite o valor do primeiro cateto: ");
            catetoA = entradaDados.nextDouble();
            System.out.print("Digite o valor do segundo cateto: ");
            catetoB = entradaDados.nextDouble();
                // Utilizando a Classe Math do pacote java.lang, OBS não precisa importar
                // O metodo .sqrt() retorna a raiz quadrada de um número
             hipotenusaC = (catetoA * catetoA) + (catetoB * catetoB);
            //hipotenusaC = Math.sqrt((catetoA * catetoA) + (catetoB * catetoB)) ; 
            hipotenusaC = Math.sqrt(hipotenusaC);
            System.out.println("O vlaor da hipotenusa e : "+ hipotenusaC);
            System.out.printf("O valor da Hipotenusa é: %.2f\n", hipotenusaC);
                // Outra forma de apresentar, com a saída formatada
            System.out.printf("O valor da Hipotenusa é: %.2f\n", Math.sqrt((catetoA * catetoA) + (catetoB * catetoB)));
                // Aqui fazendo uso do metodo, potenciação, que utiliza dois parametros .pow(valorVariavel, expoente)
            System.out.printf("O valor da Hipotenusa é: %.2f\n", Math.sqrt(Math.pow(catetoA, 2) + Math.pow(catetoB, 2)) );
   */     
        
          // Questão 2
          // A)(4 pontos). Implemente um programa em Java que receba os dados digitados pelo
          // usuário no console do NetBeans, nesta sequência: o nome do usuário e em seguida
          // um valor inteiro positivo. Em seguida o programa deve verificar se o valor 
          // digitado é par ou ímpar e imprimir no console uma mensagem com o nome do 
          // usuário, o valor digitado e o resultado da verificação se número par ou ímpar.
       /* 
            String nomeUsuario;
            int valorInteiro;
            Scanner leituraDados = new Scanner(System.in);
            
            System.out.print("Digite seu Nome: ");
            nomeUsuario = leituraDados.nextLine();
            System.out.print("Digite um valor inteiro positivo: ");
            valorInteiro = leituraDados.nextInt();
            
            if(valorInteiro % 2 == 0)
                System.out.printf("%s O número %d é PAR!\n", nomeUsuario, valorInteiro);
               // System.out.printf("%S O número %d é PAR!\n", nomeUsuario, valorInteiro);
           // else
            //    System.out.printf("%s o número %d é ÍMPAR!\n", nomeUsuario, valorInteiro);
            
            if(valorInteiro % 2 != 0)
                System.out.printf("%s o número %d é ÍMPAR!\n", nomeUsuario, valorInteiro);         
                // System.out.printf("%S o NÚMERO %d é %S\n", nomeUsuario, valorInteiro, (valorInteiro%2==0)? "PAR":"IMPAR");
     */   
           // Questao 2
           //A)(2 pontos). Implemente um programa em Java que leia dois números inteiros
           //digitados pelo usuário no console do NetBeans, num1 e num2. O programa deve
           //fazer as seguintes comparações, se: num1 igual num2; num1 diferente num2; 
           //num1 menor num2; num1 maior num2; num1 menor ou igual num2; num1 maior ou
           //igual num2; também se a condição de uma ou mais dessas instruções for 
           //verdadeira o programa deverá apresentar no console uma mensagem
           //discriminando-as. Ex.: O número1 é igual ao número2.
        /*
          int num1;
          int num2;
          Scanner ler = new Scanner(System.in);
          
          System.out.print("Digite o Primeiro número: ");
          num1 = ler.nextInt();
          System.out.print("Digite o Segundo número: ");
          num2 = ler.nextInt();
          
          if(num1 == num2)
              System.out.printf("O número: %d é IGUAL ao número: %d.\n",num1, num2);
          if(num1 != num2)
              System.out.printf("O número: %d é DIFERENTE do número: %d.\n",num1, num2);
          if(num1 < num2)
              System.out.printf("O número: %d é MENOR que o número: %d.\n",num1, num2);
          if(num1 > num2)
              System.out.printf("O número: %d é MAIOR que o número: %d.\n",num1, num2);
          if(num1 >= num2)
              System.out.printf("O número: %d é MAIOR OU IGUAL ao número: %d.\n",num1, num2);
          if(num1 <= num2)
              System.out.printf("O número: %d é MENOR OU IGUAL ao número: %d.\n",num1, num2);     
      */   
          // Questão 2
          //B)(6 pontos). Uma empresa quer calcular o salário de seus funcionários. 
          //Sabendo que esta empresa gratifica em 9% os salários e que sobre este
          //salário bruto é cobrado o Imposto de Renda (IR) na folha de pagamento. 
          //Implemente um programa em Java que receba do usuário os seguintes dados
          //digitados no console do Netbeans, nesta ordem: o nome do funcionário e em
          //seguida seu salário. O programa deve calcular e apresentar no console uma
          //mensagem personalizada com o nome do funcionário, com o valor do salário
          //digitado, o valor da gratificação, o valor do IR a ser descontado e o
          //valor liquido recebido pelo funcionário já descontados o IR. Utilizando
          //a seguinte tabela de alíquota de descontos do IR:
 /*         
          String nomeFuncionario;
          double salarioBase;
          double gratificacaoPercentil = 9;
          
          Scanner entrada = new Scanner(System.in);
          
          System.out.print("Nome do funcionário: ");
          nomeFuncionario = entrada.nextLine();
          System.out.print("Digite seu sálario: ");
          salarioBase = entrada.nextDouble();
          
          if( (salarioBase + (salarioBase * gratificacaoPercentil)/100) <= 1903.98){
              System.out.printf("Funcionário: %S\n", nomeFuncionario);
              System.out.printf("Salário: %.2f\n", salarioBase);
              System.out.printf("Gratificação: %.2f\n", (salarioBase * gratificacaoPercentil)/100);
              System.out.println("Imposto Renda: Isento");
              System.out.printf("Salário recebido: %.2f\n", salarioBase + (salarioBase * gratificacaoPercentil)/100);
          }
          if((salarioBase + (salarioBase * gratificacaoPercentil)/100) > 1903.98 && (salarioBase + (salarioBase * gratificacaoPercentil)/100) <= 2826.65){
              System.out.printf("Funcionário: %S\n", nomeFuncionario);
              System.out.printf("Salário: %.2f\n", salarioBase);
              System.out.printf("Gratificação: %.2f\n", (salarioBase * gratificacaoPercentil)/100);
              System.out.printf("Aliquota de 7,5%% ,Imposto Retido: %.2f.\n",(salarioBase + (salarioBase * gratificacaoPercentil)/100)- ((salarioBase * 7.5)/100) );
              System.out.printf("Salário recebido: %.2f\n", salarioBase + (salarioBase * gratificacaoPercentil)/100 - (salarioBase * 7.5)/100);
          }
                  
          if((salarioBase + (salarioBase * gratificacaoPercentil)/100) > 2826.65 && (salarioBase + (salarioBase * gratificacaoPercentil)/100) <= 3751.05){
              System.out.printf("Funcionário: %S\n", nomeFuncionario);
              System.out.printf("Salário: %.2f\n", salarioBase);
              System.out.printf("Gratificação: %.2f\n", (salarioBase * gratificacaoPercentil)/100);
              System.out.printf("Aliquota de 15%% ,Imposto Retido: %.2f.\n",(salarioBase + (salarioBase * gratificacaoPercentil)/100)- ((salarioBase * 15)/100));
              System.out.printf("Salário recebido: %.2f\n", salarioBase + (salarioBase * gratificacaoPercentil)/100 - (salarioBase * 15)/100 );

          }
                  
          if((salarioBase + (salarioBase * gratificacaoPercentil)/100) > 3751.05 && (salarioBase + (salarioBase * gratificacaoPercentil)/100) <= 4664.68){
              System.out.printf("Funcionário: %S\n", nomeFuncionario);
              System.out.printf("Salário: %.2f\n", salarioBase);
              System.out.printf("Gratificação: %.2f\n", (salarioBase * gratificacaoPercentil)/100);
              System.out.printf("Aliquota de 22,5%%,Imposto Retido: %.2f.\n",(salarioBase + (salarioBase * gratificacaoPercentil)/100)- ((salarioBase * 22.5)/100));
              System.out.printf("Salário recebido: %.2f\n", salarioBase + (salarioBase * gratificacaoPercentil)/100 - (salarioBase * 22.5)/100);
          }
                  
          if((salarioBase + (salarioBase * gratificacaoPercentil)/100) > 4664.68){
              System.out.printf("Funcionário: %S\n", nomeFuncionario);
              System.out.printf("Salário: %.2f\n", salarioBase);
              System.out.printf("Gratificação: %.2f\n", (salarioBase * gratificacaoPercentil)/100);
              System.out.printf("Aliquota de 27,5%%,Imposto Retido: %.2f.\n",(salarioBase + (salarioBase * gratificacaoPercentil)/100)- ((salarioBase * 27.5)/100));
              System.out.printf("Salário recebido: %.2f\n", salarioBase + (salarioBase * gratificacaoPercentil)/100 - (salarioBase * 27.5)/100);
          } 
  */    

     // Outra forma de responder Questão 2 B)
   /*       
          String nomeFuncionario;
          double salarioBase;
          double gratificacaoPercentil = 9;
          double gratificacao;
          double aliquotaIR = 0;
          double impostoRetido;
          Scanner entrada = new Scanner(System.in);
          
          System.out.print("Nome do funcionário: ");
          nomeFuncionario = entrada.nextLine();
          System.out.print("Digite seu sálario: ");
          salarioBase = entrada.nextDouble();
          
          gratificacao = (salarioBase * gratificacaoPercentil)/100;
          
          if( (salarioBase + gratificacao) <= 1903.98){
              System.out.printf("Funcionário: %S\n", nomeFuncionario);
              System.out.printf("Salário: %.2f\n", salarioBase);
              System.out.printf("Gratificação: %.2f\n", gratificacao);
              System.out.println("Imposto Renda: Isento");
              System.out.printf("Salário recebido: %.2f\n", salarioBase + gratificacao);
          }
          else {
              if((salarioBase + gratificacao) >= 1903.99 && (salarioBase + gratificacao) <= 2826.65)
                  aliquotaIR = 7.5;
              if((salarioBase + gratificacao) >= 2826.66 && (salarioBase + gratificacao) <= 3751.05)
                  aliquotaIR = 15;
              if((salarioBase + gratificacao) >= 3751.06 && (salarioBase + gratificacao) <= 4664.68)
                  aliquotaIR = 22.5;
              if((salarioBase + gratificacao) > 4664.68)
                  aliquotaIR = 27.5;
              
              impostoRetido = (salarioBase + gratificacao)*aliquotaIR/100 ;
              
              System.out.printf("Funcionário: %S\n", nomeFuncionario);
              System.out.printf("Salário: %.2f\n", salarioBase);
              System.out.printf("Gratificação: %.2f\n", gratificacao);
              System.out.printf("Aliquota de %.2f ,Imposto Retido: %.2f.\n", aliquotaIR, impostoRetido);
              System.out.printf("Salário recebido: %.2f\n", salarioBase + gratificacao - impostoRetido);
          }
   */
   /*  // Mais Outra forma de responder Questão 2 B)
       // Solução do Gabriel apresentada em Sala
        
        Scanner input= new Scanner(System.in);
        String nome;
        double salario;
        double gratificacao;
        double imposto;
        double impostoFinal;
        double salarioInicial;
        double salarioAumentado;
        System.out.println("Informe seu nome: ");
        nome= input.nextLine();
        System.out.println("Informe seu salário: ");
        salario= input.nextDouble();
        salarioInicial=salario;
        gratificacao= (salario*9)/100;
        salario+=gratificacao;
        salarioAumentado=salario;
        
        if (salario<=1903.98){
            imposto=0;
        }else if (salario >=1903.99 && salario<= 2826.65){
            imposto=7.5;
        }else if (salario>=2826.66 && salario <= 3751.05){
            imposto=15;
        }else if (salario>=3751.06 && salario<=4664.68){
            imposto=22.5;
        }else {
            imposto=27.5;
        }
        
        impostoFinal=(salario*imposto)/100;
        salario-=impostoFinal;
        
        System.out.println(nome+", seu salário bruto era: "+salarioInicial +".\nCom o aumento de 9% seu salário ficou: "+salarioAumentado+". \nFoi descontado " +imposto+"%. \nSeu salário final é de: "+salario);
   */     

    }
}