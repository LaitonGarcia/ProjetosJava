/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package segundoSemestre;
 
public class TestandoBoolean {
    
    

    public static boolean autentica(String usuario, String[] listaUsuarios) {
       // for (String listaUsuario : listaUsuarios) {
         //   if (usuario.equals(listaUsuario)) {
        for(int i=0; i < listaUsuarios.length; i++){
            if (usuario.equals(listaUsuarios[i])){
                //opcionalmente faz alguma coisa aqui.
                return true;
            } // fim do if
        } // fim do for
        //opcionalmente faz alguma coisa aqui.
        return false;
    }// fim do metodo autentica
    public static void main( String[ ] args ){
        String listaUsuarios[] = new String[4];
        listaUsuarios[0]= "laiton";
        listaUsuarios[1]= "joao";
        listaUsuarios[2]= "jose";
        listaUsuarios[3]= "luis";
        System.out.println("O usuário é convidado? "+autentica("laiton", listaUsuarios));
    }// fim do main
}// fim da classe TestandoBoolean
