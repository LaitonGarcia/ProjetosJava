/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package primeiroSemestre;

/**
 *
 * @author GARCIA
 */
public class Escopo_variavel {
    static int y =7;
    public static void main( String[ ] args ){
         int x = 0;
         int total = 0;
         System.out.println("Y começa valendo " + y );
         for(int i=0;i<2;i++){
           int y = i;
           System.out.println("Y no for é " + y );
         }// fim do for
         while( x <= 3 ){
            int y;
            y = x * x;
            System.out.println("Y no while "+ y );
            System.out.printf("x = %d \n", x);
            total = soma(y);
            ++x;
          } // fim do while
          System.out.printf( "Y vale %d\n", y );
          System.out.printf( "Total vale %d\n", total );	
     }// fim do main
    public static int soma(int x){
        System.out.println("y em soma é = " +y);
        return y+=x;
    }// fim método soma
}// fim da Classe Escopo_variavel


