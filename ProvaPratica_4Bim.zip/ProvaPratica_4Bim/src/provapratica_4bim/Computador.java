/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package provapratica_4bim;

/**
 *
 * @author GARCIA
 */
public class Computador {
    private int codigoComputador;
    private String sistemaOperacional;
    private int sala;

    public int getCodigoComputador() {
        return codigoComputador;
    }

    public void setCodigoComputador(int codigoComputador) {
        this.codigoComputador = codigoComputador;
    }

    public String getSistemaOperacional() {
        return sistemaOperacional;
    }

    public void setSistemaOperacional(String sistemaOperacional) {
        this.sistemaOperacional = sistemaOperacional;
    }

    public int getSala() {
        return sala;
    }

    public void setSala(int sala) {
        this.sala = sala;
    }
    public String mostrarComputador(){
        return "\nCódigo Computador: "+codigoComputador+
                "\nSO: "+sistemaOperacional+
                "\nSala: "+sala;
    }
}// fim classe computador
