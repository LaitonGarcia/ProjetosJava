/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package aprendendometodos;

import java.util.Scanner;

/**
 *
 * @author GARCIA
 */
public class AprendendoMetodos {

   public static double multiplicacao(int quantidade, double valorUnitario){
       
       return quantidade * valorUnitario ;
   }
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        String nome;
        String saida;

        System.out.println("Digite seu nome");
        nome = entrada.nextLine();

        saida = "n";

        while (saida.equals("n")) {

            int parafusos;
            int porcas;
            int arruelas;
            double valor_total_compra;
            double parafusos_com_descontos;
            double porcas_com_descontos;
            double arruelas_com_descontos;
            double imposto;
            double total_descontos;
            
            System.out.println("Digite a quantidade de parafusos que deseja comprar?");
            parafusos = entrada.nextInt();

            System.out.println("Digite a quantidade de porcas que deseja comprar?");
            porcas = entrada.nextInt();

            System.out.println("Digite a quantidade de arruelas que deseja comprar?");
            arruelas = entrada.nextInt();

            valor_total_compra = multiplicacao(parafusos,10);
            parafusos_com_descontos = valor_total_compra;

            valor_total_compra = valor_total_compra + multiplicacao(porcas,5);
            porcas_com_descontos = valor_total_compra - parafusos_com_descontos;

            valor_total_compra = valor_total_compra + multiplicacao(arruelas,2);
            arruelas_com_descontos = (valor_total_compra - parafusos_com_descontos) - porcas_com_descontos;

            imposto = (valor_total_compra * 25) / 100;

            parafusos_com_descontos = (parafusos_com_descontos * 20) / 100;
            parafusos_com_descontos = parafusos * 10 - parafusos_com_descontos;

            porcas_com_descontos = (porcas_com_descontos * 10) / 100;
            porcas_com_descontos = porcas * 5 - porcas_com_descontos;

            arruelas_com_descontos = (arruelas_com_descontos * 30) / 100;
            arruelas_com_descontos = arruelas * 2 - arruelas_com_descontos;

            total_descontos = valor_total_compra - parafusos_com_descontos - porcas_com_descontos - arruelas_com_descontos;

            valor_total_compra = parafusos_com_descontos + porcas_com_descontos + arruelas_com_descontos;

            System.out.println(nome + "\n"
                    + "você comprou: \n"
                    + parafusos + " parafusos a 10 reais cada,\n"
                    + porcas + " porcas a 5 reais cada,\n"
                    + "e " + arruelas + " arruelas a 2 reais cada. \n"
                    + "Na sua compra no valor total de: " + valor_total_compra + " estará incluso um total de impostos de: " + imposto+ " e um total de "+total_descontos+" de descontos!");

            System.out.println("Deseja fazer outra compra?,se sim digite n,se não digite s ou S");
            entrada.nextLine();
            saida = entrada.nextLine();


    }
    
    } // fim main
}// fim classe
