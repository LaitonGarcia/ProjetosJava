/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package replicar;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import java.util.Set;


 
public class ReplicarMongo {
    public static void main(String args[]) {
    //consulta no mongo e tras os alunos
        MongoClient m = new MongoClient("10.0.0.108", 27017);
        DB db = m.getDB("cad_web");
        
        DBCollection colecao = db.getCollection("aluno");// aqui auxiliar_alteracao_web
        DBCursor cursor = colecao.find();
        while(cursor.hasNext()){
            BasicDBObject aluno = (BasicDBObject)cursor.next();
            System.out.println("Aluno nome " + aluno.getString("nome")+"cpf " +aluno.getString("cpf"));
        }
        Set<String> collections = db.getCollectionNames();
        for (String colName : collections) {
        System.out.println("\t + Collection: " + colName);
        }
        System.out.println("QTD: "+colecao.count());
        m.close();
    
    /*    // INSERE um aluno
        BasicDBObject aluno = new BasicDBObject();
        aluno.put("nome", "Maria");
        aluno.put("cpf", "65266196220");
        
        MongoClient m = new MongoClient("10.0.0.108", 27017);
        DB db = m.getDB("cad_web");
        DBCollection colecao = db.getCollection("aluno");
        
        colecao.insert(aluno);
        m.close();
  */
    }// fim do main
}// fim da classe


