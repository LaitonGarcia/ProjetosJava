package assocclases;

public class AssocClases {
 
    public static void main(String[] args) {
        // testando Classe Aluno
        Aluno aluno1 = new Aluno();
        aluno1.setMatricula("20141tii0302");
        aluno1.setNome("SANNYA");
        aluno1.setNotaInfo(9.8);
        aluno1.setNotaIng(10);
        aluno1.setNotaMat(10);
        System.out.println(aluno1.fichaPessoal());
        System.out.println("Sua matricula é "+aluno1.getMatricula());
        System.out.println("Seu nome: "+aluno1.getNome());
        System.out.printf("Media: %.2f",aluno1.media());
        
       // Testando Classe Turma
        Turma turma = new Turma();
        turma.setAluno(aluno1);
        turma.setNomeTurma("Terceiro Ano Informatica");
        turma.setTurno("Vespertino");
        //System.out.println(turma.fichaTurma());
        //System.out.println("Turma "+turma.getNomeTurma()+"\nMedia "+aluno1.media());
       // System.out.printf("Turma %s\nMedia: %.2f",turma.getNomeTurma(),turma.mediaTurma() );
        turma.situacaoAluno();
        
    }// fim do main
    
}// fim classe
