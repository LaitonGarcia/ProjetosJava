
package conta;

import java.util.ArrayList;

public class TestarConta {

   
    public static void main(String[] args) {
        Pessoa pessoa = new Pessoa();
        ArrayList<Pessoa> clientes = new ArrayList<Pessoa>();
        pessoa.setCpf("111");
        pessoa.setNome("Laiton");
        clientes.add(pessoa);
        Pessoa pessoa2 = new Pessoa();
        pessoa2.setCpf("222");
        pessoa2.setNome("Marcos");
        clientes.add(pessoa2);
        Pessoa pessoa3 = new Pessoa();
        pessoa3.setCpf("333");
        pessoa3.setNome("Geovanna");
        clientes.add(pessoa3);
        Pessoa pessoa4 = new Pessoa();
        pessoa4.setCpf("444");
        pessoa4.setNome("Pablo");
        clientes.add(pessoa4);
        Pessoa pessoa5 = new Pessoa("Ingred", "0000000");
        Conta conta = new Conta();
        conta.setCodigoConta(111);
        conta.setSaldo(1000000);
        //conta.setCliente(pessoa);
        conta.setClientes(clientes);
        //conta.ApresentarContaCorrente();
        System.out.println(clientes.size());
       if(conta.pesquisarCliente("Geovanna") != null)
            conta.pesquisarCliente("Geovanna").ApresentarPessoa();
       else
            System.out.println("Não encontrado!") ;
        
    }// fim do main
    
}// fim classe TestarConta
