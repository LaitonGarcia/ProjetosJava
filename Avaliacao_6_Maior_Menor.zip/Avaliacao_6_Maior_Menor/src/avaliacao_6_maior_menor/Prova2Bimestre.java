/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package avaliacao_6_maior_menor;


import java.util.Scanner;

/**
 *
 * @author GARCIA
 */
public class Prova2Bimestre {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        int num_conta;
        String nome_usuario;
        double saldo=0;
        double deposito;
        double saque;
        int num = -1;// variável de controle do while e switch
        
        
        System.out.println("Digite seu número de conta: ");
        num_conta = teclado.nextInt();
        System.out.println("Digite seu nome: ");
        teclado.nextLine(); 
        nome_usuario = teclado.nextLine(); 
        System.out.println("Digite o valor do dinheiro a ser depositado: ");
        deposito = teclado.nextDouble();
        saldo += deposito;
        
            while(num != 0){
                do{
                    System.out.println(nome_usuario + ", de número de conta "+num_conta+ ", escolha uma das opções abaixo:\n");
                    System.out.println("1 - Verificar Saldo; ");
                    System.out.println("2 - Fazer depósito; ");
                    System.out.println("3 - Fazer saque; ");
                    System.out.println("0 - Encerrar Sessão; ");
                    num = teclado.nextInt();
                }while(num < 0 && num > 3);
                switch(num){                

                    case 1:
                        System.out.println("O cliente "+nome_usuario+ ", de número de conta "+ num_conta + " tem saldo de: "+ saldo + " reais");
                        System.out.println("Deseja fazer outra transação(1) ou encerrar a sessão(0)? ");
                        num = teclado.nextInt();                    
                        break;

                    case 2:
                        System.out.println("Digite o valor a ser depositado: ");
                        deposito = teclado.nextInt();
                        saldo += deposito;
                        System.out.println("O seu saldo atual é de: "+ saldo);                    
                        System.out.println("Deseja fazer outra transação(1) ou encerrar a sessão(0)? ");
                        num = teclado.nextInt();                    
                        break;

                    case 3:
                        System.out.println("Digite o valor a ser sacado: ");
                        saque = teclado.nextInt();
                        saldo -= saque;

                        if(saldo >= 0 ){
                            System.out.println("O seu saldo atual é de: "+ saldo);                    
                            System.out.println("Deseja fazer outra transação(1) ou encerrar a sessão(0)? ");
                            num = teclado.nextInt();  
                        }else{
                            System.out.println("Não é possível fazer o saque, pois o valor solicitado é maior que o saldo !!!"); 
                            saldo += saque;
                        }

                        break;                                  
                    case 0:
                        System.out.println(nome_usuario + ", Muito Obrigado. Fim da sessão!");
                }//Fim do switch
            
            }//Fim do while
    }// fim do main
    
}// fim da classe
