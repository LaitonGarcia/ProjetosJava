/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caixaeletronico;

/**
 *
 * @author GARCIA
 */
public class Conta {

    private int numeroConta;
    private Pessoa cliente = new Pessoa();
    private double saldo;
    private int senha; // senha com 6 dígitos
    

    public int getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(int numeroConta) {
        this.numeroConta = numeroConta;
    }

    public Pessoa getCliente() {
        return cliente;
    }

    public void setCliente(Pessoa cliente) {
        this.cliente = cliente;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public int getSenha() {
        return senha;
    }
    
    public void setSenha(int senha) {// existe a opção da senha ser String
        if(senhaTem6digitos(senha))
            this.senha = senha;
        else
            System.out.println("Senha Inválida!");
    }
    
    public String mostrarConta() {
        return "Conta número: " + numeroConta
                + "\n" + cliente.mostrarPessoa()
                + "\nSenha: "+senha
                + "\nSaldo atual: "+saldo ;             
    }
    public boolean senhaTem6digitos(int senhaParaCadastrar){
        // primeiramente transforma o int em String
        String senhaParaConferir = String.valueOf(senhaParaCadastrar);
        return senhaParaConferir.length()== 6;
    }
  /* // Se senha for do tipo String, então:
    public boolean senhaTem6digitos(String senhaParaCadastrar){
          return senhaParaConferir.length()== 6;
    }
  */ 
    public boolean conferirSenhaLogin(int senhaDigitada){
        return senha == senhaDigitada;
    }
  /* // se senha for do Tipo String, então:
    public boolean conferirSenhaLogin(String senhaDigitada){
        return senha.equals(senhaDigitada);
    }
  */
    public boolean conferirNumeroContaLogin(int contaDigitada){
        return numeroConta == contaDigitada;
    }
    public void deposito(double valorDoDeposito){
        saldo += valorDoDeposito; // mesmo que saldo = saldo + valor;
    }
    public void saque(double valorDoSaque){
        if(verificarSuficienciaSaldo(valorDoSaque))
            saldo -= valorDoSaque; // mesmo que saldo = saldo - valor;
        else
            System.out.println("Saldo Insuficiente!");
    }
    public boolean verificarSuficienciaSaldo(double valorDoSaque){
        return valorDoSaque <= saldo;
    }

   
}// Fim da Classe Conta
