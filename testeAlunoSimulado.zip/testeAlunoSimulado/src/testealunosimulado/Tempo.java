

package testealunosimulado;


public class Tempo {
    private int hora;
    private int minuto;
    private int segundo;
    private boolean open = true;
    
    public Tempo(int hora, int minuto, int segundo){
        if(hora<0 || minuto<0 || segundo<0){
            System.out.println("Não existe Tempo Negativo!");
           //this.open = false;
            setOpen(false);
        }
        else{
            this.hora = hora;
            this.minuto = minuto;
            this.segundo = segundo;
        }
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        if(hora<24)
            this.hora = hora;
        else
            System.out.println("Hora inválida!");
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        if(minuto<60)
            this.minuto = minuto;
        else
            System.out.println("Minuto inválido!");
    }

    public int getSegundo() {
        return segundo;
    }

    public void setSegundo(int segundo) {
        if(segundo<60)
            this.segundo = segundo;
        else
            System.out.println("Segundos inválido!");
    }
    
    public String toStringTempo(){
        if(this.open){
            String horas = "Horas: "+hora+":"+minuto+":"+segundo+" "+faseDoDia();
            return horas;}
        else
            return "";
    }
    
    public String faseDoDia(){
        
        if(hora>=5 && hora<12)
            return "Manhã";
        if(hora>=12 && hora<18)
            return "Tarde";
        else
            return "Noite";
    }    

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }
    
}
