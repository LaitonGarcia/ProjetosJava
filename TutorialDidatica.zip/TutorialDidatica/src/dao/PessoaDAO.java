/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

    import factory.ConnectionFactory; 
    import modelo.Pessoa; 
    import java.sql.*; 
    import java.sql.PreparedStatement;

public class PessoaDAO {
    
    private Connection connection;     
   /* int id;     
    String nome;     
    String cargo;        
    String telefone;*/
    
    public PessoaDAO(){       
        this.connection = new ConnectionFactory().getConnection();     
    }    
    
    public void adiciona(Pessoa pessoa){      
        String sql = "INSERT INTO pessoa(nome,cargo,telefone) VALUES(?,?,?)"; 
        try {            
            PreparedStatement stmt = connection.prepareStatement(sql); 
            stmt.setString(1, pessoa.getNome()); 
            stmt.setString(2, pessoa.getCargo());                       
            stmt.setString(3, pessoa.getTelefone());            
            stmt.execute();           
            stmt.close(); 
        } catch (SQLException u) { 
            throw new RuntimeException(u);         
        }     
    }
}
