/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package avaliacao_6_maior_menor;

import java.util.Scanner;

/**
 *
 * @author GARCIA
 */
public class Avaliacao_6_Maior_Menor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
     Scanner input= new Scanner(System.in);
 /*    
     int num1;
     int num2;
     int num3;
     int menu=-1;
     do{   
     
        System.out.println("Digite um número");
        num1=input.nextInt();
        System.out.println("Digite um número");
        num2=input.nextInt();
        System.out.println("Digite um número");
        num3=input.nextInt();
        while(menu < 0 || menu > 4){
           System.out.println("MENU\n 1- Apresentar Maior valor\n 2- Apresentar Menor valor\n 3- Apresentar em ordem Crescente de valor\n 4- Apresentar em ordem Decrescente de valor\n0 - Encerrar Sessão");
           menu=input.nextInt();
        }
        switch (menu){
            case 1: 
                   if (num1>num2&&num1>num3){
                       System.out.println("O maior número é : "+num1);

                   }else if(num2>num1&&num2>num3){
                       System.out.println("O maior número é : "+num2);
                   }else
                       System.out.println("O maior número é : "+num3);
                   break;
           case 2: 
                   if (num1<num2&&num1<num3){
                       System.out.println("O menor número é : "+num1);

                   }else{ System.out.print("O menor número é : "); 
                        System.out.println(num2<num1 && num2<num3 ? num2: num3);
                   }
                   break;

           case 3:
                   if(num1<num2&&num1<num3){
                         if(num3>num2){
                                System.out.println("Ordem crescente: "+num1+" "+num2+" "+num3);
                         }
                   }
                   if(num1<num2&&num1<num3){
                            if(num2>num3){
                                  System.out.println("Ordem crescente: "+num1+" "+num3+" "+num2);
                            }
                   }
           if(num2<num1&&num2<num3){
                if(num1>num3){
                    System.out.println("Ordem crescente: "+num2+" "+num3+" "+num1);
                }
           }if(num2<num1&&num2<num3){
                if(num3>num1){
                    System.out.println("Ordem crescente: "+num2+" "+num1+" "+num3);
                }
           }
           if(num3<num1&&num3<num2){
                if(num1>num2){
                    System.out.println("Ordem crescente: "+num3+" "+num2+" "+num1);
                }
           }
           if(num3<num2&&num3<num1){
                if(num2>num1){
                    System.out.println("Ordem crescente: "+num3+" "+num1+" "+num2);
                }
           }
           break;

           case 4:if(num1>num2&&num1>num3){
                if(num3<num2){
                    System.out.println("Ordem decrescente: "+num1+" "+num2+" "+num3);
                }
               }
           if(num1>num2&&num1>num3){
                if(num2<num3){
                    System.out.println("Ordem decrescente: "+num1+" "+num3+" "+num2);
               }
           }
           if(num2>num1&&num2>num3){
                if(num1<num3){
                    System.out.println("Ordem decrescente: "+num2+" "+num3+" "+num1);
                }
           }if(num2>num1&&num2>num3){
                if(num3<num1){
                    System.out.println("Ordem decrescente: "+num2+" "+num1+" "+num3);
                }
           }
           if(num3>num1&&num3>num2){
                if(num1<num2){
                    System.out.println("Ordem decrescente: "+num3+" "+num2+" "+num1);
                }
           }
           if(num3>num2&&num3>num1){
                if(num2<num1){
                    System.out.println("Ordem decrescente: "+num3+" "+num1+" "+num2);
                }
           }
           break;
          // default: System.out.println("Escolha uma opção válida");
   }
       menu=-1; 
      }while(menu != 0);  
 */       
     
        int num_1;
        int num_2;
        int num_3;
        int maiorNum;
        int menorNum;
        int meio = 0;
        int controleSwitch = -1;
        do{
           System.out.print("Digite primeiro número inteiro:");
           num_1 = input.nextInt();
           System.out.print("Digite segundo número numero:");
           num_2 = input.nextInt();
           System.out.print("Digite terceiro número numero:");
           num_3 = input.nextInt(); 

           maiorNum = Math.max(num_1, Math.max(num_2, num_3));
           menorNum = Math.min(num_1, Math.min(num_2, num_3));

           if(num_1 != maiorNum && num_1 != menorNum) 
                meio = num_1;
           else
               if(num_2 != maiorNum && num_2 != menorNum) 
                    meio = num_2;
               else
                   meio = num_3;
           while(controleSwitch < 0 || controleSwitch > 4){
                System.out.print("Escolha a operação:\n");
                System.out.print("1 - Maior Número\n2 - Menor Número\n");
                System.out.print("3 - Ordem Crescente\n4 - Ordem Decrescente: \n");
                System.out.print("0 - ENCERRAR SESSÃO\n");
                controleSwitch = input.nextInt();
           }
            switch (controleSwitch) {
            case 1:
                System.out.println("Maior número: "+maiorNum);
                break;
            case 2:
                System.out.println("Menor número: "+menorNum);
                break;
            case 3:
                System.out.println("Ordem Crescente "+menorNum+" "+meio+" "+maiorNum);
                break;
            case 4:
                System.out.println("Ordem Decrescente "+maiorNum+" "+meio+" "+menorNum);
                break;
            default:
                System.out.println("Não existe essa opção!");
                break;
            } // fim do switch
            controleSwitch = -1; 
         }while(controleSwitch != 0);
         
        
        
        

        
        
            

    } // fim do main
    
}// fim da classe
