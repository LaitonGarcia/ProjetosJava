

package javaapplication48;

import java.util.Scanner;


public class JavaApplication48 {
    public static void mensagemNome(){
        System.out.println("digite nome ");
    }
    public static void mensagemInt(){
        System.out.println("digite algarismo ");
    }
    public static int lerInteiro(){
        Scanner ler = new Scanner(System.in);
        mensagemInt();
        int algarismo = ler.nextInt();
        return algarismo;
    }
    public static String lerNome(){
        Scanner ler = new Scanner(System.in);
        mensagemNome();
        String nome = ler.nextLine();
        return nome;
    }
    public static int gerarDigA(int a, int b, int c, int d, int e){
        return (a*6 + b*5 + c*4 + d*3 + e*2)%7;
    }
    public static int gerarDigB(int a, int b, int c, int d, int e){
        return (a*2 + b*3 + c*4 + d*5 + e*6)%7;
    }
    public static boolean autenticar(int digito, int alg){
        return digito == alg;
    }
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int alg1;
        int alg2;
        int alg3;
        int alg4;
        int alg5;
        int digitoA;
        int digitoB;
        String nome;
            // gerar codigo
        alg1 = lerInteiro();
        alg2 = lerInteiro();
        alg3 = lerInteiro();
        alg4 = lerInteiro();
        alg5 = lerInteiro();
        nome = lerNome();
        digitoA = gerarDigA(alg1,alg2,alg3,alg4,alg5);
        digitoB = gerarDigB(alg1,alg2,alg3,alg4,alg5);
        System.out.printf("Codigo CC: %d%d%d%d%d - %d%d\n",alg1,alg2,alg3,alg4,alg5,digitoA,digitoB);
            // autenticar codigo
        alg1 = lerInteiro();
        alg2 = lerInteiro();
        alg3 = lerInteiro();
        alg4 = lerInteiro();
        alg5 = lerInteiro();
        
        if(autenticar(gerarDigA(alg1,alg2,alg3,alg4,alg5),digitoA) & autenticar(gerarDigB(alg1,alg2,alg3,alg4,alg5),digitoB)) 
            System.out.println("código válido ");
        else
            System.out.println("código INVáLIDO ");
        
    }//fim do main
    
}//fim da classe
