/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package provapratica_4bim;

/**
 *
 * @author GARCIA
 */
public class Cliente {
    private String nome;
    private String cpf;
    private String fone;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        if(validarCpf(cpf))
            this.cpf = cpf;
        else
            System.out.println("CPF Inválido!");
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }
    public boolean validarCpf(String cpf){
        return cpf.length()==11;
    }
    public String mostrarCliente(){
        return "\nNome: "+nome+"\nCPF: "+cpf+"\nFone: "+fone;
    }
}// Fim Classe Cliente
