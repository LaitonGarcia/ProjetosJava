/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package primeirometodo;

import java.util.Scanner;

/**
 *
 * @author GARCIA
 */
public class PrimeiroMetodo {

    public static void menu(){
       
        System.out.println("MENU\n\n1 - Verificar saldo\n2 - Fazer depósito\n3 - Fazer saque\n0 - Encerrar sessão");
    }
    
    public static void main(String[] args) {
        Scanner input= new Scanner (System.in);
       
       int numero_conta;
       String nome;
       double valor;
       
       
       System.out.println("Digite o número da Sua conta: ");
       numero_conta =input.nextInt();
       
       System.out.println("Digite o seu nome: ");
       nome =input.nextLine();
       nome =input.nextLine();
       
       System.out.println("Digite o valor que deseja depositar: ");
       valor =input.nextDouble();
       
       menu();
       int opcao = input.nextInt();
       
       
       while (opcao!=0){
       
       switch (opcao){
              case 1:
                  System.out.println(nome+", sua conta é "+numero_conta+" e possui o saldo de R$ "+valor);
                  break;
              case 2:
                  System.out.println("Digito o valor que será depositado: ");
                  double deposito=input.nextDouble();
                  valor+=deposito;
                  System.out.println(nome+", seu saldo atualizado é R$ "+valor);
                  break;
              case 3:
                  System.out.println("Digite o valor que deseja sacar: ");
                  double saque=input.nextDouble();
                  if(saque>valor){
                      System.out.println("Você não possui saldo suficiente\nEscolha a opção desejada: ");
                      
                  }else{
                      valor-=saque;
                    System.out.println(nome+", seu saldo atualizado é R$ "+valor);  
                  }
                  }
                      
       System.out.println("MENU\n\n1 - Verificar saldo\n2 - Fazer depósito\n3 - Fazer saque\n0 - Encerrar sessão");
       opcao = input.nextInt();
       
    }
    }
    
}
