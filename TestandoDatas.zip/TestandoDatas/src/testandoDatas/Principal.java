/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package testandoDatas;


import java.sql.SQLException;


/**
 *
 * @author GARCIA
 */
public class Principal {
    public static void main(String[] args) throws SQLException{
        NovaData novaData = new NovaData();
        novaData.setCodigo(1);
        //novaData.setNome("Maria Da guia");
        //novaData.cadastrar(novaData);
        novaData.pesquisar(novaData);
        
    } // fim metodo main()
    
} // fim da Classe Principal
