
package entidades;

/**
 *
 * @author rlopes
 */
public class Formacao {

    public long id;
    public String nome;
    public String titulacao;
    public String lotacao;
    public String cpf;

}
