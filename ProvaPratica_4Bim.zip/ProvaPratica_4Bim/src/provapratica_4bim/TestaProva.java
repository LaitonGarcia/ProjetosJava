
package provapratica_4bim;

/**
 *
 * @author GARCIA
 */
public class TestaProva {

    public static void main(String[] args) {
        //testando cliente
        Cliente cliente = new Cliente();
        cliente.setCpf("12345678910");
        cliente.setFone("89999991111");
        cliente.setNome("A Lenda");
        //System.out.println(cliente.mostrarCliente());
        // testando Horas
        Horas inicioSessao = new Horas();
        inicioSessao.setHora(14);
        //System.out.println(inicioSessao.mostrarHora());
        Horas encerraSessao = new Horas();
        encerraSessao.setHora(17);
        // testando Data
        Data data = new Data();
        data.setAno(2017);
        data.setDia(21);
        data.setMes(03);
        //System.out.println(data.mostrarData());
        // Testando Computador
        Computador computador = new Computador();
        computador.setCodigoComputador(111);
        computador.setSala(4);
        computador.setSistemaOperacional("Windows");
        //System.out.println(computador.mostrarComputador());
        // testando Sessao
        Sessao sessao = new Sessao();
        sessao.setCliente(cliente);
        sessao.setDataSessao(data);
        sessao.setEncerraSessao(encerraSessao);
        sessao.setInicioSessao(inicioSessao);
        sessao.setMaquina(computador);
        sessao.calcularTotalPagar();// chamar após inserir hora inicio e encerramento
        //sessao.mostrarSessao();
        sessao.resumoSessao();
    }// fim do main
    
}// fim classe TestaProva
