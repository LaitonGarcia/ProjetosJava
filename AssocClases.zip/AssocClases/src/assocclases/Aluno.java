
package assocclases;


public class Aluno {
    private String nome;
    private String matricula;
    private double notaInfo;
    private double notaMat;
    private double notaIng;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public double getNotaInfo() {
        return notaInfo;
    }

    public void setNotaInfo(double notaInfo) {
        this.notaInfo = notaInfo;
    }

    public double getNotaMat() {
        return notaMat;
    }

    public void setNotaMat(double notaMat) {
        this.notaMat = notaMat;
    }

    public double getNotaIng() {
        return notaIng;
    }

    public void setNotaIng(double notaIng) {
        this.notaIng = notaIng;
    }
    public double media(){
        return  (notaInfo + notaMat + notaIng)/3 ;
    }
    public String fichaPessoal(){
        return "Nome: "+nome+"\nMatricula: "+matricula+"\nNota Info: "+notaInfo+
                "\nNota Matematica: "+notaMat+"\nNota Ingles: "+notaIng+"\nMedia: "+media();
    }
    
}
