/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeiroSemestre;

import static java.lang.Math.pow;
import static java.lang.Math.sqrt;
import java.util.Scanner;

/**
 *
 * @author GARCIA
 */
public class Aula_1_printf_operadores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
/*
     int numero;
     String nome;
     Scanner input = new Scanner(System.in);
     
     System.out.print("entre com o nome: ");
     nome = input.nextLine();
     System.out.print("entre com o numero: ");
     numero = input.nextInt();
    
     if(numero%2==0) System.out.println(nome + " o numero digitado é par!");
     if(numero%2!=0) System.out.println(nome + " o numero digitado é ímpar!");
  */   
        /*
         //Criando em apenas 1 linha de codigo
         System.out.printf("     *\n    ***\n   *****\n  *******\n *********\n    |||\n");
      
         System.out.printf("-----------\n");
         //Criando em varias linhas de codigo
         System.out.println("     /*\\");
         System.out.println("    /***\\");
         System.out.println("   /*****\\");
         System.out.println("  /*******\\");
         System.out.println(" /*********\\");
         System.out.println("     |||\n");
         */
        /*
         // Operadores de incremento e decremento na prática
         // Perceba como os operadores de incremento alteram o valor da variável na propria linha de instrução
        
         int a = 0; // inicializando a variavel 'a' do tipo inteiro
    
         System.out.printf("Nesta instrução (a=0;) o valor de 'a' é:%+5d\n", a);
         System.out.printf("         Agora (++a;) assume este valor:%+5d\n", ++a);
         System.out.printf("Nesta instrução (a++;) CONTINUA valendo:%+5d\n", a++);
         System.out.printf("              Agora sim o valor de 'a'é:%+5d\n", a); 
         */
        /*
         //  Resposta do Hilton ao 1 desafio
         int um = 10;  
         int dois = 15;
         int soma = um+dois;
         System.out.println (" O resultado da soma é: " + soma+" \"olha eu aqui!\"");
         */
        /*  // Resposta do Alison ao 1 desafio
         int n1= 1; 
         int n2 = 4;
         int soma = n1 + n2;
         System.out.println(soma); 
         */
        /*
         // Resposta do Felipe Castro ao 1 desafio
         int num_1 = 1; 
         int num_2 = 2;
         int resultado = num_1+num_2;
         System.out.println(" A soma do numero " + num_1 + " com o numero " + num_2 + " e igual a " + resultado);
         */
        /*  
         //  Resposta do Gabriel ao 1 desafio
         int a = 3; 
         int b = 2;
         System.out.println("A soma é " + (10%2));
         */
        /*
         // Resposta ao ex.:1 da Primeira Avaliação
         int a=0, b=0, x = 5, y = 10;
         x++;
         y--;
         a = x++;
         b = ++y;
         System.out.printf("A = %d B = %d X = %d Y = %d\n",a, b, x, y);
         */
        /*      
         // Uma forma para visualizar o comportamento do operadore de incremento
         // na linha de instrução
         int a=0, b=0, x = 5, y = 10;
         System.out.printf("A = %d B = %d X = %d Y = %d\n",a, b, x++, y);
         System.out.printf("A = %d B = %d X = %d Y = %d\n",a, b, x, y--);
         System.out.printf("A = %d B = %d X = %d Y = %d\n",a = x++, b, x, y);
         System.out.printf("A = %d B = %d X = %d Y = %d\n",a, b = ++y, x, y);
         System.out.printf("A = %d B = %d X = %d Y = %d\n",a, b, x, y);
         */
       /* 
         // Resposta ao ex.:2 da Primeira Avaliação
         int x = 0, y = 0, z =0;
         System.out.printf("X=%d Y=%d Z=%d\n",x,y, z); 
         x = y = 10;
         System.out.printf("X=%d Y=%d Z=%d\n",x,y, z); 
         z = ++x;
         System.out.printf("X=%d Y=%d Z=%d\n",x,y, z); 
         x-=x;
         System.out.printf("X=%d Y=%d Z=%d\n",x,y, z); 
         y++;
         System.out.printf("X=%d Y=%d Z=%d\n",x,y, z); 
         x = x + y -(z--);
         System.out.printf("X=%d Y=%d Z=%d\n",x,y, z);   
         */
    /*    
         // Resposta ao ex.:3 da Primeira Avaliação
         int a, b, c, d;
         int x = 1, y = 2, z = 3, k = 4;
         a = ++x;
         b = y;
         c = z++;
         d = k;
         System.out.printf("A = %d B = %d C = %d D = %d\n", a, b, c, d);
         System.out.printf("X = %d Y = %d Z = %d K = %d\n", x, y, z, k);
    */     
        /*
         // Troca de valores entre duas variáveis (utilizando variável auxiliar)
        
         int num1 = 2;
         int num2 = 3;
         System.out.println("O Valor de num1 é: "+num1+"e o num2: "+num2+".");
         int auxiliar = num1;
         num1 = num2;
         num2 = auxiliar;
         System.out.println("Agora os valor mudaram num1 é: "+num1+" e o num2: "+num2+".");
         */
        /*
         // Desafio prático em sala: troca de valores utilizando somente DUAS variáveis(ADIÇÃO/SUBTRAÇÃO).
         int num1 = -5;
         int num2 = 10;
     
         System.out.println("            O Valor do num1 é: "+num1+" e o num2: "+num2+".");
         num1 += num2;
         num2 = num1-num2;
         num1 -= num2;
         System.out.println("Agora os valor mudaram num1 é: "+num1+" e o num2: "+num2+".");
         */
        /*  
         // Desafio prático em sala: troca de valores utilizando somente DUAS variáveis(MULTIPLICAÇÃO/DIVISÃO).
         int num1 = 8;
         int num2 = 3;
         System.out.println("            O Valor de num1 é: "+num1+"e o num2: "+num2+".");
         num1 *= num2;
         num2 = num1/num2;
         num1 /= num2;
         System.out.println("Agora os valor mudaram num1 é: "+num1+" e o num2: "+num2+"."); 
         */
          
         // EXEMPLO DE COMO UTILIZAR A CLASSE SCANNER, para entrada de dados do teclado
        
         // Cria um Scanner para obter entrada da janela de comando
       /*  Scanner input = new Scanner(System.in);
         int numero1; // primeiro número a adicionar
         int numero2; // segundo numero a adicionar
         int resultado; // resultado da soma do numero1 e numero2
      
         System.out.print("Entre com o primeiro inteiro: "); // console
         numero1 = input.nextInt(); // lê o primeiro número fornecido pelo usuário
      
         System.out.print("Entre com o segundo inteiro: "); // console
         numero2 = input.nextInt(); // lê o segundo número fornecido pelo usuário
      
         resultado = numero1 + numero2; // soma os numeros, depois armazena o total em resultado
      
         System.out.printf("O resultado é %d\n", resultado);
      */  
       /* Scanner ler = new Scanner(System.in);
        System.out.println("Digite abaixo as notas do aluno: ");
        double nota1 = ler.nextDouble();
        double nota2 = ler.nextDouble();
        double nota3 = ler.nextDouble();
        double nota4 = ler.nextDouble();
        double media = (nota1*1+nota2*1+nota3*1+nota4*5)/8;
        System.out.println("A media do aluno é: "+media);
       */ 
    } // fim do metodo main    
} // fim da classe Aula_1_printf_operadores
