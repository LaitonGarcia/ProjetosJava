/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades.util;

import java.util.Date;

/**
 *
 * @author Rubens
 */
public class TituloEleitor {

    private String tituloEleitor;
    private String tituloEleitorSecao;
    private String tituloEleitorZona;
    private String tituloEleitorUf;
    private Date tituloEleitorDataEmissao;

    public String getTituloEleitor() {
        return tituloEleitor;
    }

    public void setTituloEleitor(String tituloEleitor) {
        this.tituloEleitor = tituloEleitor;
    }

    public String getTituloEleitorSecao() {
        return tituloEleitorSecao;
    }

    public void setTituloEleitorSecao(String tituloEleitorSecao) {
        this.tituloEleitorSecao = tituloEleitorSecao;
    }

    public String getTituloEleitorZona() {
        return tituloEleitorZona;
    }

    public void setTituloEleitorZona(String tituloEleitorZona) {
        this.tituloEleitorZona = tituloEleitorZona;
    }

    public String getTituloEleitorUf() {
        return tituloEleitorUf;
    }

    public void setTituloEleitorUf(String tituloEleitorUf) {
        this.tituloEleitorUf = tituloEleitorUf;
    }

    public Date getTituloEleitorDataEmissao() {
        return tituloEleitorDataEmissao;
    }

    public void setTituloEleitorDataEmissao(Date tituloEleitorDataEmissao) {
        this.tituloEleitorDataEmissao = tituloEleitorDataEmissao;
    }

}
