/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package primeiroSemestre;

import java.util.Scanner;

/**
 *
 * @author GARCIA
 */
public class Aula_6_exprRegular {
    
    
   /* public static void main(String[] args) {
    
     
        Scanner teclado = new Scanner(System.in);
        String valor;
        do{
           System.out.println("Entre com o primeiro valor");
           valor=teclado.nextLine();
        }while(!valor.matches("^[1-7]*$")); 



         //  expressões regulares
         if(valor.matches("^[a-zA-Z]*$"))
              System.out.println("Apenas letras");
         if(valor.matches("^[0-9]*$")) 
              System.out.println("Apenas numeros");
 
    
    }
   */
    
    
}
