/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conta;

/**
 *
 * @author GARCIA
 */
public class Pessoa {
    private String nome;
    private String cpf;
    public Pessoa(String nome, String cpf){
        this.nome = nome;
        this.cpf = cpf;
   }
    public Pessoa (){}
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public void ApresentarPessoa(){
        System.out.println("Nome: "+nome);
        System.out.println("CPF: "+cpf);
    }
}
