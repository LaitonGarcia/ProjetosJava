/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package testealunosimulado;

import java.time.Instant;
import java.time.LocalDate;


public class TesteAlunoSimulado {

    
    public static void main(String[] args) {
        Aluno alu1 = new Aluno(1,"joao");
        
        System.out.println(alu1.toStringAluno());
        
        alu1.setMedia(9.6);
        
        alu1.resultadoFinal(alu1);
        
        Tempo tempo1 = new Tempo(18,4,30);
        System.out.println(tempo1.toStringTempo());
        Instant agora = Instant.now();
        System.out.println(agora);
        LocalDate hoje = LocalDate.now();
        System.out.println(hoje);
    }
    
}
