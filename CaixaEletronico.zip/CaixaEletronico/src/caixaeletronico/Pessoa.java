/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package caixaeletronico;

/**
 *
 * @author GARCIA
 */
public class Pessoa {
    private String nome;
    private String cpf;
    private String fone;
   
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        if(verificaCpf(cpf))
            this.cpf = cpf;
       else
            System.out.println("CPF inválido!");
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }
    public String mostrarPessoa(){
        return  "Nome: "+nome+"\nCPF: "+cpf+
                "\nTelefone: "+fone+"\n";
    }
    public boolean verificaCpf(String cpf){
        return cpf.length()==11;
    }
    
}
