

package aprendendojava;

import static java.lang.Math.pow;


class Calculos {
    
    public int soma (int num1, int num2){
        return num1 + num2;
    }
    
    public double quadrado(int num){
        return pow(num,2);
  }
    
    public double cubo (int num) {
        return pow(num,3);
    }
    
    public boolean igualdade(int num1, int num2){
       /*if(num1 == num2)return true;  // exemplo mal implementado do tipo boolean
            else
                return false;*/
        boolean resultado = (num1 == num2);
        return resultado;
    }
    
    public boolean diferente(int num1, int num2){
       boolean resultado = (num1 != num2);
       return resultado;
    }
    
    public boolean menorQue(int num1, int num2){
        boolean resultado = (num1 < num2);
        return resultado;
    }
    
    public boolean maiorQue (int num1, int num2){
       boolean resultado = (num1 > num2);
       return resultado;
    }
    
    public boolean menorIgaul(int num1, int num2){
        boolean resultado = (num1 <= num2);
        return resultado;
    }
    
    public boolean maiorIgual(int num1, int num2){
        boolean resultado = (num1 >= num2);
        return resultado;
    }
    
    public boolean ehNumero(String testar){
        boolean  resultado = true;
        
        for (int i = 0; i < testar.length(); i++){
            if(! Character.isDigit(testar.charAt(i))){ // função que testa se é um numero
                resultado = false;                     // repare a negação (!), se não for numero
                break;                                 // atribui falso a resultado e sai do for
            }
        }
        return resultado;
    }
    
    public boolean somenteCharNum(String testar){  // tambem testando se é somente numero ou letra      
        boolean resultado = (testar.matches("(?i)^[a-záàãâçéêíóôõúÁÀÃÂÇÉÊÍÓÔÕÚ]*$") ||
                             testar.matches("^[0-9]*$"));// (?i) não diferenciar maiusculo de minusculo
            return resultado;
    }
    
}
/*  
      outros verificadores se numero ou letras
Testar se só tem números

    String testar = "dados a serem testados";
    if(testar.matches("^[0-9]*$")){fazer instrução;}  // ^ sinal de exclusivo

         ou se decimal

    if(testar.matches("^[0-9]*[.]{0,1}[0-9]*$")){fazer nstrução;}

Testar se só tem letras

    String testar = "dados a serem analisados";
    if(testar.contains("^[a-Z]")) System.out.println("tem letras");
    else System.out.println("apenas numeros"); 

          outro modo, cercando todos os caracteres

    String testar = "dados a serem testados";
    
    if(testar.matches("^[a-zA-Záàãâçéêíóôõú]*$"))
        System.out.println("só tem letres");
    else if(testar.matches("^[0-9]*$"))
        System.out.printl("Só tem digitos");
    else
        System.out.println("Outros");

*/