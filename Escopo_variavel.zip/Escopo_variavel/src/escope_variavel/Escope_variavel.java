/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package escope_variavel;

/**
 *
 * @author GARCIA
 */
public class Escope_variavel {

   static int y;
    
    public static void main(String[] args) {
         
        System.out.println("Y no main "+y);
        for(int i=0;i<2;i++){
           int y = 5;
           System.out.println("Y no for "+y);
        }
        int y=9;
        int i=0;
        while(i<2){  
           System.out.printf("Y no while %d\n",y);
            ++i;
            System.out.printf("Y no while %d",i);
        }
    }
    
}
