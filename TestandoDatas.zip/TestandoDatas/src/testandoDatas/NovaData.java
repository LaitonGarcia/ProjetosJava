/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package testandoDatas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author GARCIA
 */
public class NovaData {
  private  int codigo;
  private  String nome;
  private  Calendar dataCadastro;
  private String dataCadastroString;

    public String getDataCadastroString() {
        return dataCadastroString;
    }

    public void setDataCadastroString(String dataCadastroString) {
        this.dataCadastroString = dataCadastroString;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Calendar getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Calendar dataCadastro) {
        this.dataCadastro = dataCadastro;
    }
    
    public void cadastrar(NovaData novaData){
        ConexaoMysql conectar = new ConexaoMysql();
        String sql = "INSERT INTO testandoDatas(nome) VALUES(?)";        
        PreparedStatement inserir; 
        try {
            inserir = conectar.fazConexao().prepareStatement(sql);
            inserir.setString(1, novaData.getNome());            
            inserir.execute();           
            inserir.close();
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        } // fim do try...catch 
    } // fim metodo cadastrar
    
    public void pesquisar(NovaData novaData) { 
        ConexaoMysql conectar = new ConexaoMysql();
        String sql = "select codigo, nome, CURDATE() from testandoDatas where codigo = ?";
        NovaData resultado = new NovaData();
        ResultSet res; 
        PreparedStatement pesquisar;  
        try { 
            pesquisar = conectar.fazConexao().prepareStatement(sql);
            pesquisar.setInt(1,novaData.getCodigo());
            res = pesquisar.executeQuery();
            while (res.next()) { 
                resultado.setCodigo(res.getInt(1)); 
                resultado.setNome(res.getString(2));
                resultado.setDataCadastroString(res.getString(3));
               // java.sql.Timestamp dataCad = res.getTimestamp(3);
                //resultado.setDataCadastro(TimestampParaCalendar(dataCad));
               // Calendar calendar = Calendar.getInstance();
               // calendar.setTimeInMillis(dataCad.getTime());
              //  resultado.setDataCadastro(calendar);
                System.out.println("codigo: "+resultado.getCodigo()); 
                System.out.println("nome: "+resultado.getNome()); 
              //  System.out.println("data cadastro calendar: "+ resultado.getDataCadastro()); 
                System.out.println("data cadastro string: "+resultado.getDataCadastroString()); 
             }
            //return resultado;
          } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Nenhum registro encontrado: " + ex);
            //return null ;
          } // fim do try...catch
        
    }// fim metodo pesquisar
    public Calendar TimestampParaCalendar(Timestamp value)
    {    
        SimpleDateFormat format;
        format = new SimpleDateFormat("dd/MM/yyyy HH:MM");    
        format.setLenient(false);
        String stringData = format.format(value);
        Calendar data = Calendar.getInstance();
        try {
            data.setTimeInMillis(format.parse(stringData).getTime());
        } catch (ParseException e) {            
            e.printStackTrace();
        }
        return data;       
    }   
}
