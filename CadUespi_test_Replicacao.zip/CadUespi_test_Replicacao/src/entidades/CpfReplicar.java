/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

/**
 *
 * @author GARCIA
 */
public class CpfReplicar {

    private String cpf;
    private String cpfOld;
    private String tipoPessoa;
    
   

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
     public String getCpfOld() {
        return cpfOld;
    }

    public void setCpfOld(String cpfOld) {
        this.cpfOld = cpfOld;
    }
    
    public String getTipoPessoa() {
        return tipoPessoa;
    }

    public void setTipoPessoa(String tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }

}
